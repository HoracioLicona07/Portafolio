import openai  

openai.api_key = "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"

conversation = ""

i = 1

while (i !=0):
    question = input("User: ")
    conversation += "\nUser: " + question + "\nAI:"
    response = openai.Completion.create(
        model = "davinci",  #text-davinci-003
        prompt = conversation,
        temperature = 0.9, 
        max_tokens = 150,
        top_p = 1.0,
        frequency_penalty = 0.0,
        presense_penalty =0.6,
        stop = ["\n", "User: ", "AI: "]
    )
    answer = response.choices[0].text.strip()
    conversation += answer
    print("AI: " + answer + "\n")