import openai
#Aquí colocamos el APIkey en Platformopenai
openai.api_key = "Ask-qdBHE1PQh2FNkJE3MZw6T3BlbkFJW8ib8xMH609922eWztej" 

conversation = "NombreChatbot es un chatbot prueba"

while True:
    question = input("Tu: ")
    conversation += "\nTu: " + question + "\nNombreChatbot"
    response = openai.Completion.create(
        model = "text-curie-001",
        prompt = conversation,
        temperature = 0.5,
        max_tokens = 100,
        echo = True,
        n = 1,
        logprobs = 0,
        top_p = 0.3,
        frequency_penalty = 0.5,
        presence_penalty = 0.0,
        stop = [" Tu: ", "NombreChatbot: "]
    )
    
answer = response.choices[0].text.strip()
conversation += answer 
print("NombreChatbot: " + answer + "\n")
    