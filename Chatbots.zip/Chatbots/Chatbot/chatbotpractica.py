import openai
#Aquí colocamos el APIkey en Platformopenai
openai.api_key = "Ask-qdBHE1PQh2FNkJE3MZw6T3BlbkFJW8ib8xMH609922eWztej" 

conversation = "NombreChatbot es un chatbot prueba"

while True:
    def tokenize_ada(prompt):
        response = openai.Completion.create(
            engine='ada',
            prompt=prompt,
            max_tokens=0,
            echo=True,
            n=1,
            logprobs=0
    )
        tokens = response.choices[0]["logprobs"]["tokens"]
        positions = response.choices[0]["logprobs"]["text_offset"]
        return tokens, positions