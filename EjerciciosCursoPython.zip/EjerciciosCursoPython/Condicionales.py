edad = int(input("Escribe tu edad: "))
if edad >= 18:
    print("Eres mayor de edad")
else: 
    print("Eres menor de edad: ")
    
numero = int(input("Escribe un numero: "))

if numero > 5:
    print("Es mayor a 5")
elif numero == 5:
    print("Es igual a 5")
elif numero == 4:
    print("Es igual a 4")
else:
    print("Es menor a 4")