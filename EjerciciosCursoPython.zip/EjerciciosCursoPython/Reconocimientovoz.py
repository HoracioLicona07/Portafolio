#pip install pipwin
#pip install pywhatkit
#pip install pyautogui
#pip install SpeechRecognition
#pip install pyttsx3
#pip install PyAudio
#pip install --upgrade speechrecognition

import speech_recognition as sr    #importar paquetería de identificador de voz
import pyttsx3      #importar paquetería de voz 
import webbrowser   #importar paquetería para abrir páginas de internet
import time    #para dar tiempo de espera a la apertura de páginas
import pyautogui  #paquetería de control de computadora
import smtplib    #referencia a correos electrónicos y conexión segura 
import getpass    #modulo para ingresar contraseña en la terminal
import os 
from email.message import EmailMessage
import ssl  #para seguridad en envío de correos
from time import sleep

name = 'cortana' #le establecí el nombre  la asistente

engine = pyttsx3.init() #creamos variable engine para paquetería de voz

voices = engine.getProperty('voices') #crear la variable de voz del chat
engine.setProperty('voices', voices[0].id) #seleccionamos tipo de voz


#engine.say es para que nuestro programa pueda hablar 
engine.say("Hola buen día soy Cortana, ¿en qué te puedo ayudar?")
engine.runAndWait() #da la introducción y espera para que podamos hablar

listener = sr.Recognizer() #ubicamos a listener con sr y detecta idioma en el que hablamos

for voice in voices:
    print(voice)

def talk(text):
    engine.say(text)
    engine.runAndWait()


try:    #comando try para poder probar el programa
    with sr.Microphone() as source:
        print("Escuchando...")
        voice = listener.listen(source)   #variable voice ligado a listener
        listener.adjust_for_ambient_noise(source)  #se ajusta a los ruidos del ambiente
        rec = listener.recognize_google(voice, language='es-MX')
        rec = rec.lower() #convierte todas las letras a minúsculas
        talk("Acabo de escuchar la orden" + rec)
        if "mándale mensaje a santiago" in rec:
            webbrowser.open('https://web.whatsapp.com/send?phone=+525517280976') 
            time.sleep(20)
            #print("El mensaje fue envíado")
            for i in range(1):
                    pyautogui.typewrite('Hola Santiago, ¿como estas? te habla Cortana la asistente de Horacio')
                    pyautogui.press('enter')
            print("El mensaje fue envíado")
except sr.UnknownValueError:
    print('No te entiendo')
except sr.RequestError as e:
    print("No se pueden encontrar resultados en Google Speech Recognition service; {0}".format(e))
except UnboundLocalError:
    print("No te entendí intenta de nuevo")