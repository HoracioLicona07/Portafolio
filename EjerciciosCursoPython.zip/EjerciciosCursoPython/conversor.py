#valor_dolar = float(18.59)
#pesos_mexicanos = " "
#def conversor(pesos_mexicanos, valor_dolar):
#    pesos = input("¿Cuántos pesos $ mexicanos tienes?: ")
#    pesos = float(pesos)
#    dolares = pesos /valor_dolar
#    dolares = round(dolares, 2)
#    dolares = str(dolares)
#    print("Tienes $" + dolares + "dólares")
    
#print(conversor(pesos_mexicanos, valor_dolar))



#Python 3.9.13
def conversor(tipo_pesos, valor_dolar):
    pesos = input("¿Cuántos pesos $" + tipo_pesos + "tienes?: ")
    pesos = float(pesos)
    dolares = pesos /valor_dolar
    dolares = round(dolares, 2)
    dolares = str(dolares)
    print("Tienes $" + dolares + "dólares")
    
menu = """
Bienvenido al conversor de monedas 

1 - Pesos mexicanos 
2 - Pesos Colombiano
3 - Pesos Argentino

Elige una opción: """

opcion = input(menu)

if opcion == '1':
    conversor("mexicanos" , 18.59)
elif opcion == '2':
    conversor("Colombianos" , 4759.64)
elif opcion == '2':
    conversor("Argentinos" , 205.76)
else:
    print('Ingresa una opción válida, por favor')


# if opcion == '1':
#     pesos = input("¿Cuántos pesos $mexicanos tienes?: ")
#     pesos = float(pesos)
#     valor_dolar= 20.2
#     dolares = pesos /valor_dolar
#     dolares = round(dolares, 2)
#     dolares = str(dolares)
#     print("Tienes $" + dolares + "dólares")
# elif opcion == '2':
#     pesos = input("¿Cuántos pesos $mexicanos tienes?: ")
#     pesos = float(pesos)
#     valor_dolar= 20.2
#     dolares = pesos /valor_dolar
#     dolares = round(dolares, 2)
#     dolares = str(dolares)
#     print("Tienes $" + dolares + "dólares")
# elif opcion == '3':
#     pesos = input("¿Cuántos pesos $mexicanos tienes?: ")
#     pesos = float(pesos)
#     valor_dolar= 20.2
#     dolares = pesos /valor_dolar
#     dolares = round(dolares, 2)
#     dolares = str(dolares)
#     print("Tienes $" + dolares + "dólares")

