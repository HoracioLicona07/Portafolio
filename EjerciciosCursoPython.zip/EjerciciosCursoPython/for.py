# print(1)
# print(2)
# print(3)

# contador = 1 
# print(contador)
# while contador < 1000:
#     #contador = contador + 1
#     contador += 1 
#     print(contador)
    
# a = list(range(1000))
# print(a)

# for contador in range(1, 1001):
#     print(contador)
    
for i in range(10):
    print(11*i)