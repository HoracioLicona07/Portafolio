print("Ecribe dos números: ")
numero1 = input()
numero2 = input()

def suma(a,b):
    print("Se suman los números")
    resultado = a + b
    return resultado

sumatoria = suma(1, 4)
print(sumatoria)
    