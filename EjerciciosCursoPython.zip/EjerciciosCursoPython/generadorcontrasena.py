import random
import smtplib 
import os 
from email.message import EmailMessage
import ssl




def generar_contrasena():
    mayusculas = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
    minusculas = ['a', 'b', 'c', 'd', 'e', 'f', 'g']
    simbolos = ['!', '#', '$', '&', '/', '(', ')']
    numeros = ['1', '2', '3', '4', '5', '6', '7']
    
    caracteres = mayusculas + minusculas + simbolos + numeros
    
    contrasena = []
    
    for i in range(15):
        caracter_random = random.choice(caracteres)
        contrasena.append(caracter_random)
        
    contrasena = "".join(contrasena)
    return contrasena

def run():
    contrasena = generar_contrasena()
    print("Tu nueva contraseña es: " + contrasena)
    
email_emisor = 'horaciolicona0711@gmail.com'
email_contrasena = os.environ.get('EMAIL_PASSWORD')

email_receptor = 'horaciolicona0711@gmail.com'

asunto = 'Esta es mi nueva contraseña'
cuerpo = """
Hola, muy buenos días Horacio tu nueva contraseña es la siguiente: 
"""


em = EmailMessage()
em['From'] = email_emisor
em['To'] = email_receptor
em['Subject'] = asunto
em.set_content(cuerpo)

contexto = ssl.create_default_context()

with smtplib.SMTP_SSL('horaciolicona0711@gmail.com', 465, contexto=contexto) as smtp:
    smtp.login(email_emisor, email_contrasena)
    smtp.sendmail(email_emisor, email_receptor, em.as_string())
    
if __name__ == '__main__':
    run()