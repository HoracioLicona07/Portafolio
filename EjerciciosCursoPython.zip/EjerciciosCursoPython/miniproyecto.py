def es_primo(numero):
    contador = 0 
    
    for i in range(i, numero + 1):
        if i == 1 or 1 == numero:
            
#Qué pueda identificar qué tipo de datos es, si son números si es primo o no, si son pares o impares 
# y los ponga en sus respectivos conjuntos o listas. Con los datos extraídos que haga una contraseña.
#Debe de haber 4 listas
#Lista 1: Letras o símbolos
#Lista 2: Números pares y no primos
#Lista 3: Números impares y no primos
#Lista 4: Números impares y primos
