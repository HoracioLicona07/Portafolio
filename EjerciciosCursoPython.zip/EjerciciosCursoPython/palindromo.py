def palindromo(palabra):  #creamos función palindromo
    palabra = palabra.replace(' ', '')  #quitamos espacios a las frases con método replace
    palabra = palabra.upper()   #volvemos todas las letras a mayúsculas con método upper
    len(palabra)            #medimos la longitud de la palabra
    palabra_invertida = palabra[::-1]  #establecemos variable palabra_invertida con indices
    if palabra == palabra_invertida:   #condicional de comparación de palabra con palabra invertida
        return True         #regresamos el valor True
    else:
        return False
    
def run():
    palabra = input('Escribe una palabra o frase: ')
    es_palindromo = palindromo(palabra)
    if es_palindromo == True:
        print("Es palindromo")
    else:
        print("No es palindromo")
        
if __name__ == '__main__':
    run()
        