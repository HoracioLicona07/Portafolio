import keras
from keras.models import Sequential
from keras.layers import Dense
import pandas as pd

#Importamos data

data = pd.read_csv('')

#Declaramos variables
data_columnas = data.columns
labels = data[data_columnas[data_columnas != 'Strength']]
target = data['Strength']
n_cols = labels.shape[1]

#Creamos el modelo 
modelo = Sequential()

#Agregamos capas neuronas
modelo.add(Dense(50, activation = 'relu', input_shape = (n_cols,)))
modelo.add(Dense(50, activation= 'relu'))
modelo.add(Dense(1))

#Compilamos
modelo.compile(optimizer = 'adam', loss = 'mean_squared_error')

#Entrenamos
modelo.fit(labels, target, validation_split = 0.3, epochs = 100, verbose=True)