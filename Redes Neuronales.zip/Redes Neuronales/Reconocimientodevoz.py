#pip install pipwin
#pip install pywhatkit
#pip install SpeechRecognition
#pip install pyttsx3
#pip install PyAudio
#pip install --upgrade speechrecognition
import speech_recognition as sr
import pyttsx3
import webbrowser
import time
import pyautogui
import smtplib
import getpass
import os
import ssl

name = 'Elisa'

engine = pyttsx3.init()

voices = engine.getProperty('voices')
engine.setProperty('voices', voices[0].id)

engine.say("Hola buen día soy Elisa, ¿en qué te puedo ayudar?")
engine.runAndWait()

listener = sr.Recognizer()

for voice in voices:
    print(voice)
    
def talk(text):
    engine.say(text)
    engine.runAndWait()
    
try:
    with sr.Microphone() as source:
        print("Escuchando...")
        voice = listener.listen(source)
        listener.adjust_for_ambient_noise(source)
        rec = listener.recognize_google(voice, language='es-MX')
        rec = rec.lower()
        talk("Acabo de escuchar la orden" + rec)
        
except sr.UnknownValueError:
    print('No te entiendo')
except sr.RequestError as e:
    print("No se pueden encontrar resultados en Google Speech Recognition service {0}".format(e))
except UnboundLocalError:
    print("No te entendí, ¿me lo podrías volver a repetir?")