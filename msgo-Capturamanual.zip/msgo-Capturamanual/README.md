# CapturaManual Microservice

## Descripción
El microservicio `capturamanual` es una solución para la captura, liberación, y manejo de órdenes de pago en un sistema financiero. Ofrece funcionalidades como la captura de nuevas órdenes, su liberación o cancelación, la suma de importes de órdenes y el filtrado basado en diversos criterios.

## Características
- Captura y gestión de órdenes de pago
- Liberación y cancelación de órdenes
- Suma de importes y filtrado de órdenes
- Interfaz de usuario para la interacción con el sistema
- API REST para la integración con otros sistemas

## Estructura del Proyecto
El proyecto está organizado en varios directorios:

- `cmd/server`: Contiene el punto de entrada principal del servidor.
- `internal/api`: Define los manejadores de las API.
- `internal/model`: Define las estructuras de datos y la lógica de negocio.
- `internal/repository`: Contiene la lógica de acceso a datos.
- `internal/service`: Contiene la lógica de servicios de negocio.
- `pkg/db`: Configuración y conexión a la base de datos.
- `web`: Recursos estáticos y plantillas para la interfaz de usuario.

## Requisitos
- Go versión 1.18 o superior
- Docker (opcional para contenerización)
- SQL Server (u otro sistema de gestión de base de datos compatible)

## Configuración
Antes de ejecutar el microservicio, asegúrate de configurar las variables de entorno necesarias en `.env`.

## Instalación y Ejecución

### Localmente
Para ejecutar el microservicio localmente, sigue estos pasos:
1. Clona el repositorio:
   ```bash
   git clone [URL del repositorio]

go run cmd/server/main.go

docker build -t capturamanual .

Usando Docker
Para ejecutar el servicio usando Docker, sigue estos pasos:

Construye la imagen Docker:

docker build -t capturamanual .
Ejecuta el contenedor:

docker run -p 8080:8080 capturamanual
Testing
Para ejecutar las pruebas unitarias y de integración:

go test ./...