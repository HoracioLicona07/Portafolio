package main

import (
	"capturamanual/internal/api"
	"capturamanual/internal/middleware"
	"capturamanual/internal/repository"
	"capturamanual/internal/service"
	"capturamanual/pkg/configs"
	"capturamanual/pkg/database"
	"log"
	"net/http"
)

func main() {
	// Cargar la configuración
	cfg, err := configs.LoadConfig()
	if err != nil {
		log.Fatal("Error loading .env file: ", err)
	}

	// Conectar a la base de datos
	db, err := database.ConectarSQLServer()
	if err != nil {
		log.Fatalf("Error al conectar a SQL Server: %v", err)
	}
	defer db.Close() // Asegurar el cierre de la conexión

	// Inicializar el repositorio
	orderRepo := repository.NewSQLOrderRepository(db)

	// Inicializar los servicios
	paymentService := service.NewPaymentService(orderRepo)
	captureService := service.NewCaptureService(orderRepo)
	releaseService := service.NewReleaseService(orderRepo)
	cancelService := service.NewCancelService(orderRepo)
	sumService := service.NewSumService(orderRepo)
	filterService := service.NewFilterService(orderRepo)

	// Inicializar los manejadores
	orderHandler := api.NewOrderHandler(paymentService)
	captureHandler := api.NewCaptureHandler(captureService)
	releaseHandler := api.NewReleaseHandler(releaseService)
	cancelHandler := api.NewCancelHandler(cancelService)
	sumHandler := api.NewSumHandler(sumService)
	filterHandler := api.NewFilterHandler(filterService)

	// Configurar el enrutador de HTTP
	mux := http.NewServeMux()

	// Configurar las rutas
	orderHandler.SetupRoutes(mux)
	captureHandler.SetupRoutes(mux)
	releaseHandler.SetupRoutes(mux)
	cancelHandler.SetupRoutes(mux)
	sumHandler.SetupRoutes(mux)
	filterHandler.SetupRoutes(mux)

	// Configurar middleware de seguridad
	secureMux := middleware.SetSecurityHeaders(mux)

	// Iniciar el servidor HTTP con middleware de seguridad
	log.Printf("Starting server on %s", cfg.ServerAddress)
	if err := http.ListenAndServe(cfg.ServerAddress, secureMux); err != nil {
		log.Fatalf("Error starting server: %v", err)
	}
}
