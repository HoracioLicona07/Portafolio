package api

import (
	"capturamanual/internal/service"
	"encoding/json"
	"net/http"
	"strconv"
)

// CancelHandler estructura para manejar las peticiones de cancelación de órdenes de pago.
type CancelHandler struct {
	cancelService *service.CancelService
}

// NewCancelHandler crea un nuevo CancelHandler con las dependencias necesarias.
func NewCancelHandler(cancelService *service.CancelService) *CancelHandler {
	return &CancelHandler{
		cancelService: cancelService,
	}
}

// HandleCancelOrder procesa las solicitudes de cancelación de órdenes de pago.
func (h *CancelHandler) HandleCancelOrder(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	// Extraer el ID de la orden de pago de la URL.
	orderIDStr := r.URL.Query().Get("id")
	if orderIDStr == "" {
		http.Error(w, "Order ID is required", http.StatusBadRequest)
		return
	}

	orderID, err := strconv.ParseInt(orderIDStr, 10, 64)
	if err != nil {
		http.Error(w, "Invalid order ID", http.StatusBadRequest)
		return
	}

	// Cancelar la orden utilizando el servicio de cancelación.
	err = h.cancelService.CancelOrder(orderID)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(map[string]string{"message": "Order cancelled successfully"})
}

// SetupRoutes establece las rutas para el manejo de cancelaciones.
func (h *CancelHandler) SetupRoutes(mux *http.ServeMux) {
	mux.HandleFunc("/orders/cancel", h.HandleCancelOrder)
}
