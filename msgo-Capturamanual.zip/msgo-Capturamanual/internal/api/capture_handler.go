package api

import (
	"capturamanual/internal/model"
	"capturamanual/internal/service"
	"encoding/json"
	"net/http"
)

// CaptureHandler estructura para manejar las peticiones HTTP relacionadas con la captura de órdenes de pago.
type CaptureHandler struct {
	captureService *service.CaptureService
}

// NewCaptureHandler crea un nuevo CaptureHandler con las dependencias necesarias.
func NewCaptureHandler(captureService *service.CaptureService) *CaptureHandler {
	return &CaptureHandler{
		captureService: captureService,
	}
}

// HandleCreateOrder procesa las solicitudes de creación de nuevas órdenes de pago.
func (h *CaptureHandler) HandleCreateOrder(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var orderRequest model.Order
	if err := json.NewDecoder(r.Body).Decode(&orderRequest); err != nil {
		http.Error(w, "Invalid request body", http.StatusBadRequest)
		return
	}

	// Creación de la orden de pago utilizando el servicio de captura.
	order, err := h.captureService.CaptureOrder(&orderRequest)
	if err != nil {
		http.Error(w, "Failed to capture order: "+err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	json.NewEncoder(w).Encode(order)
}

// SetupRoutes establece las rutas para el manejo de la captura de órdenes de pago.
func (h *CaptureHandler) SetupRoutes(mux *http.ServeMux) {
	mux.HandleFunc("/orders/capture", h.HandleCreateOrder)
}
