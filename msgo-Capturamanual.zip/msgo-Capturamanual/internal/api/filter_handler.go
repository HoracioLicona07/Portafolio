package api

import (
	"capturamanual/internal/model"
	"capturamanual/internal/service"
	"encoding/json"
	"net/http"
)

// FilterHandler estructura para manejar las peticiones HTTP relacionadas con el filtrado de órdenes de pago.
type FilterHandler struct {
	filterService *service.FilterService
}

// NewFilterHandler crea un nuevo FilterHandler con las dependencias necesarias.
func NewFilterHandler(filterService *service.FilterService) *FilterHandler {
	return &FilterHandler{
		filterService: filterService,
	}
}

// HandleFilterOrders procesa las solicitudes de filtrado de órdenes de pago.
func (h *FilterHandler) HandleFilterOrders(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var filterCriteria model.FilterCriteria
	if err := json.NewDecoder(r.Body).Decode(&filterCriteria); err != nil {
		http.Error(w, "Invalid request body", http.StatusBadRequest)
		return
	}

	// Filtrar las órdenes de pago utilizando el servicio de filtrado.
	orders, err := h.filterService.FilterOrders(&filterCriteria)
	if err != nil {
		http.Error(w, "Failed to filter orders: "+err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(orders)
}

// SetupRoutes establece las rutas para el manejo del filtrado de órdenes de pago.
func (h *FilterHandler) SetupRoutes(mux *http.ServeMux) {
	mux.HandleFunc("/orders/filter", h.HandleFilterOrders)
}
