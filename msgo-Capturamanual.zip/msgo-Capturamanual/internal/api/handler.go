package api

import (
	"capturamanual/internal/model"
	"capturamanual/internal/service"
	"encoding/json"
	"net/http"
	"strconv"
	"strings"
)

// Constantes para los mensajes de error para evitar duplicados.
const (
	ErrMethodNotAllowed = "Method not allowed"
	ErrBadRequest       = "Bad request"
	ErrInternalServer   = "Internal server error"
)

// OrderHandler estructura para manejar las peticiones HTTP relacionadas con las órdenes de pago.
type OrderHandler struct {
	paymentService *service.PaymentService // El servicio que manejará la lógica de negocio.
}

// NewOrderHandler crea un nuevo OrderHandler con las dependencias necesarias.
func NewOrderHandler(paymentService *service.PaymentService) *OrderHandler {
	return &OrderHandler{
		paymentService: paymentService,
	}
}

// SetupRoutes establece las rutas y los manejadores.
func (h *OrderHandler) SetupRoutes(mux *http.ServeMux) {
	mux.HandleFunc("/orders/create", h.HandleCreateOrder)
	mux.HandleFunc("/orders/release/", h.HandleReleaseOrder) // Asumiendo que se añade el ID de la orden en la URL
	mux.HandleFunc("/orders/cancel/", h.HandleCancelOrder)   // Asumiendo que se añade el ID de la orden en la URL
}

// HandleCreateOrder procesa las solicitudes de creación de órdenes de pago.
func (h *OrderHandler) HandleCreateOrder(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		respondWithError(w, ErrMethodNotAllowed, http.StatusMethodNotAllowed)
		return
	}

	var orderRequest model.Order
	err := json.NewDecoder(r.Body).Decode(&orderRequest)
	if err != nil {
		respondWithError(w, ErrBadRequest+": "+err.Error(), http.StatusBadRequest)
		return
	}

	order, err := h.paymentService.CaptureOrder(orderRequest.Number, orderRequest.Amount, orderRequest.PaymentType, orderRequest.BeneficiaryInstitution, orderRequest.Priority, orderRequest.Topology)
	if err != nil {
		respondWithError(w, ErrInternalServer+": "+err.Error(), http.StatusInternalServerError)
		return
	}

	respondWithJSON(w, http.StatusCreated, order)
}

// HandleReleaseOrder procesa las solicitudes para liberar órdenes de pago.
func (h *OrderHandler) HandleReleaseOrder(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		respondWithError(w, ErrMethodNotAllowed, http.StatusMethodNotAllowed)
		return
	}

	orderID, err := parseIDFromURL(r.URL.Path, "/orders/release/")
	if err != nil {
		respondWithError(w, ErrBadRequest+": "+err.Error(), http.StatusBadRequest)
		return
	}

	err = h.paymentService.ReleaseOrder(orderID)
	if err != nil {
		respondWithError(w, ErrInternalServer+": "+err.Error(), http.StatusInternalServerError)
		return
	}

	respondWithJSON(w, http.StatusOK, map[string]string{"message": "Order released"})
}

// HandleCancelOrder procesa las solicitudes para cancelar órdenes de pago.
func (h *OrderHandler) HandleCancelOrder(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		respondWithError(w, ErrMethodNotAllowed, http.StatusMethodNotAllowed)
		return
	}

	orderID, err := parseIDFromURL(r.URL.Path, "/orders/cancel/")
	if err != nil {
		respondWithError(w, ErrBadRequest+": "+err.Error(), http.StatusBadRequest)
		return
	}

	err = h.paymentService.CancelOrder(orderID)
	if err != nil {
		respondWithError(w, ErrInternalServer+": "+err.Error(), http.StatusInternalServerError)
		return
	}

	respondWithJSON(w, http.StatusOK, map[string]string{"message": "Order cancelled"})
}

// parseIDFromURL extrae el ID de una orden de la URL.
func parseIDFromURL(url, prefix string) (int64, error) {
	idStr := strings.TrimPrefix(url, prefix)
	return strconv.ParseInt(idStr, 10, 64)
}

// respondWithError envía un error en formato JSON con el código de estado HTTP proporcionado.
func respondWithError(w http.ResponseWriter, message string, code int) {
	respondWithJSON(w, code, map[string]string{"error": message})
}

// respondWithJSON envía una respuesta en formato JSON con el código de estado HTTP proporcionado.
func respondWithJSON(w http.ResponseWriter, code int, payload interface{}) {
	response, err := json.Marshal(payload)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		// Si la serialización falla, responde con error 500 y detén el procesamiento.
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte(ErrInternalServer))
		return
	}

	// Configuramos el header para contenido de tipo JSON y escribimos la respuesta con el código de estado apropiado.
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	w.Write(response) // Envía la respuesta serializada como JSON.
}

// Aquí podrías agregar más manejadores o lógica de ayuda si es necesario.
