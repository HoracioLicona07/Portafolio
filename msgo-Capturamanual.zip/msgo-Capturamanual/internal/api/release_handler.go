package api

import (
	"capturamanual/internal/service"
	"encoding/json"
	"net/http"
	"strconv"
	"strings"
)

// ReleaseHandler estructura para manejar las peticiones HTTP relacionadas con la liberación de órdenes de pago.
type ReleaseHandler struct {
	releaseService *service.ReleaseService
}

// NewReleaseHandler crea un nuevo ReleaseHandler con las dependencias necesarias.
func NewReleaseHandler(releaseService *service.ReleaseService) *ReleaseHandler {
	return &ReleaseHandler{
		releaseService: releaseService,
	}
}

// HandleReleaseOrder procesa las solicitudes para liberar órdenes de pago.
func (h *ReleaseHandler) HandleReleaseOrder(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	// Extrae el ID de la orden de la URL.
	parts := strings.Split(r.URL.Path, "/")
	if len(parts) < 3 {
		http.Error(w, "Invalid URL", http.StatusBadRequest)
		return
	}
	orderID, err := strconv.ParseInt(parts[len(parts)-1], 10, 64)
	if err != nil {
		http.Error(w, "Invalid order ID", http.StatusBadRequest)
		return
	}

	// Llamar al servicio de liberación para liberar la orden de pago.
	err = h.releaseService.ReleaseOrder(orderID)
	if err != nil {
		http.Error(w, "Failed to release order: "+err.Error(), http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(map[string]string{"message": "Order released successfully"})
}

// SetupRoutes establece las rutas para el manejo de la liberación de órdenes de pago.
func (h *ReleaseHandler) SetupRoutes(mux *http.ServeMux) {
	mux.HandleFunc("/orders/release/", h.HandleReleaseOrder)
}
