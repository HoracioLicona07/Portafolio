package api

import (
	"capturamanual/internal/model"
	"capturamanual/internal/service"
	"encoding/json"
	"net/http"
)

// SumHandler estructura para manejar las peticiones HTTP relacionadas con la suma de órdenes de pago.
type SumHandler struct {
	sumService *service.SumService
}

// NewSumHandler crea un nuevo SumHandler con las dependencias necesarias.
func NewSumHandler(sumService *service.SumService) *SumHandler {
	return &SumHandler{
		sumService: sumService,
	}
}

// HandleSumOrders procesa las solicitudes para sumar el importe de órdenes de pago.
func (h *SumHandler) HandleSumOrders(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var sumRequest model.SumRequest
	if err := json.NewDecoder(r.Body).Decode(&sumRequest); err != nil {
		http.Error(w, "Invalid request body", http.StatusBadRequest)
		return
	}

	// Llama al servicio de suma para sumar las órdenes de pago.
	total, err := h.sumService.SumOrders(sumRequest.StartID, sumRequest.EndID)
	if err != nil {
		http.Error(w, "Failed to sum orders: "+err.Error(), http.StatusInternalServerError)
		return
	}

	response := map[string]float64{"total": total}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(response)
}

// SetupRoutes establece las rutas para el manejo de la suma de órdenes de pago.
func (h *SumHandler) SetupRoutes(mux *http.ServeMux) {
	mux.HandleFunc("/orders/sum", h.HandleSumOrders)
}
