package middleware

import (
	"net/http"
)

// AuthMiddleware verifica la presencia y validez del token de autenticación en la solicitud.
func AuthMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Aquí deberías extraer el token de la solicitud, por ejemplo, de un encabezado Authorization
		token := r.Header.Get("Authorization")

		// Aquí implementarías la lógica para validar el token.
		// Si es válido, permites que la solicitud continúe.
		// Si no es válido, respondes con un error y no llamas a 'next'.
		if token == "" {
			http.Error(w, "Unauthorized", http.StatusUnauthorized)
			return
		}

		// Si está bien, procedemos a la siguiente función en la cadena de middleware.
		next.ServeHTTP(w, r)
	})
}

// SetupAuthRoutes establece las rutas que requieren autenticación.
func SetupAuthRoutes(mux *http.ServeMux) {
	// Aquí puedes añadir las rutas que requieren autenticación.
	// Por ejemplo:
	// mux.Handle("/secure", AuthMiddleware(http.HandlerFunc(secureHandler)))
}
