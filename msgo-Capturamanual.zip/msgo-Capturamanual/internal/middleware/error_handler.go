package middleware

import (
	"encoding/json"
	"log"
	"net/http"
)

// ErrorResponse es la estructura que define el cuerpo de respuesta de error estándar.
type ErrorResponse struct {
	Error string `json:"error"`
	Code  int    `json:"code"`
}

// ErrorHandler es un middleware que captura cualquier error lanzado en el stack de middlewares y lo maneja.
func ErrorHandler(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Ejecuta el handler y captura cualquier panic.
		defer func() {
			if err := recover(); err != nil {
				log.Printf("recovering from panic, reason: %v", err)
				WriteErrorResponse(w, http.StatusInternalServerError, "Internal Server Error")
			}
		}()

		next.ServeHTTP(w, r)
	})
}

// WriteErrorResponse escribe un mensaje de error JSON formateado y un código de estado HTTP al ResponseWriter.
func WriteErrorResponse(w http.ResponseWriter, code int, message string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	err := json.NewEncoder(w).Encode(ErrorResponse{
		Error: message,
		Code:  code,
	})
	if err != nil {
		log.Printf("error writing error response: %v", err)
	}
}

// SetupErrorHandling envuelve todos los manejadores con el middleware de manejo de errores.
func SetupErrorHandling(mux *http.ServeMux) {
	// Aquí puedes envolver tus rutas con el ErrorHandler
	// Por ejemplo:
	// mux.Handle("/example", ErrorHandler(YourHandler()))
}
