package middleware

import (
	"net/http"
)

// SetSecurityHeaders establece encabezados de respuesta HTTP para mejorar la seguridad.
func SetSecurityHeaders(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Prevenir ataques de Clickjacking
		w.Header().Set("X-Frame-Options", "DENY")

		// Prevenir ataques XSS
		w.Header().Set("X-Content-Type-Options", "nosniff")

		// Configuraciones de política de seguridad de contenido (CSP)
		// w.Header().Set("Content-Security-Policy", "default-src 'self'")

		// Habilitar protección XSS para navegadores que aún lo soportan
		w.Header().Set("X-XSS-Protection", "1; mode=block")

		// Configuraciones para evitar que el navegador utilice heurística para el tipo MIME
		w.Header().Set("X-Content-Type-Options", "nosniff")

		// Strict-Transport-Security mejora la seguridad en conexiones HTTPS
		// w.Header().Set("Strict-Transport-Security", "max-age=63072000; includeSubDomains")

		next.ServeHTTP(w, r)
	})
}

// SetupSecurity establece el middleware de seguridad para las rutas proporcionadas.
func SetupSecurity(mux *http.ServeMux) {
	// Envuelve todas las rutas necesarias con el middleware de seguridad.
	// Por ejemplo:
	// mux.Handle("/", SetSecurityHeaders(http.HandlerFunc(YourMainHandler)))
}
