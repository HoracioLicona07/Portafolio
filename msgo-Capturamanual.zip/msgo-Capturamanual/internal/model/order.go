package model

import (
	"errors"
	"strings"
	"time"
)

// OrderStatus define los posibles estados de una orden de pago.
type OrderStatus string

const (
	StatusCaptured     OrderStatus = "CAPTURADA"
	StatusReleased     OrderStatus = "LIBERADA"
	StatusCancelled    OrderStatus = "CANCELADA"
	StatusLocalError   OrderStatus = "ERROR_LOCAL"
	StatusBanxicoError OrderStatus = "ERROR_BANXICO"
)

// Order representa una orden de pago en el sistema.
type Order struct {
	ID                     int64       `json:"id"`
	Number                 string      `json:"number"`
	OperationDate          time.Time   `json:"operation_date"`
	Amount                 float64     `json:"amount"`
	Status                 OrderStatus `json:"status"`
	PaymentType            string      `json:"payment_type"`
	BeneficiaryInstitution string      `json:"beneficiary_institution"`
	Priority               string      `json:"priority"`
	Topology               string      `json:"topology"`
	CreatedAt              time.Time   `json:"created_at"`
	UpdatedAt              time.Time   `json:"updated_at"`
}

// SumRequest define los criterios para sumar órdenes de pago.
type SumRequest struct {
	// Define los campos necesarios para sumar las órdenes de pago.
	// Por ejemplo, puedes incluir rango de fechas, rango de números de orden, etc.
	FromDate   *time.Time `json:"from_date,omitempty"`
	ToDate     *time.Time `json:"to_date,omitempty"`
	FromNumber string     `json:"from_number,omitempty"`
	ToNumber   string     `json:"to_number,omitempty"`
	StartID    int64      `json:"start_id"`
	EndID      int64      `json:"end_id"`
	// Agrega aquí cualquier otro campo que necesites para sumar las órdenes.
}

// FilterCriteria define los criterios de filtrado para las órdenes de pago.
type FilterCriteria struct {
	Number                 string
	OperationDate          *time.Time
	Amount                 *float64
	Status                 OrderStatus
	PaymentType            string
	BeneficiaryInstitution string
	Priority               string
	Topology               string
}

// Matches verifica si una orden de pago coincide con los criterios de filtrado.
func (fc *FilterCriteria) Matches(order *Order) bool {
	if fc.Number != "" && fc.Number != order.Number {
		return false
	}
	if fc.OperationDate != nil && !fc.OperationDate.Equal(order.OperationDate) {
		return false
	}
	if fc.Amount != nil && *fc.Amount != order.Amount {
		return false
	}
	if string(fc.Status) != "" && fc.Status != order.Status {
		return false
	}
	if fc.PaymentType != "" && fc.PaymentType != order.PaymentType {
		return false
	}
	if fc.BeneficiaryInstitution != "" && fc.BeneficiaryInstitution != order.BeneficiaryInstitution {
		return false
	}
	if fc.Priority != "" && fc.Priority != order.Priority {
		return false
	}
	if fc.Topology != "" && fc.Topology != order.Topology {
		return false
	}
	return true
}

// NewOrder crea y valida una nueva instancia de Order.
func NewOrder(number string, amount float64, paymentType, beneficiaryInstitution, priority, topology string) (*Order, error) {
	order := &Order{
		Number:                 number,
		OperationDate:          time.Now(),
		Amount:                 amount,
		Status:                 StatusCaptured,
		PaymentType:            paymentType,
		BeneficiaryInstitution: beneficiaryInstitution,
		Priority:               priority,
		Topology:               topology,
		CreatedAt:              time.Now(),
		UpdatedAt:              time.Now(),
	}

	if err := order.Validate(); err != nil {
		return nil, err
	}

	return order, nil
}

// Validate realiza la validación detallada de la orden de pago.
func (o *Order) Validate() error {
	var validationErrors []string

	if o.Amount <= 0 {
		validationErrors = append(validationErrors, "amount must be positive")
	}
	if o.Number == "" {
		validationErrors = append(validationErrors, "number is required")
	}
	if o.PaymentType == "" {
		validationErrors = append(validationErrors, "payment type is required")
	}
	// Agregar más validaciones según sea necesario.

	if len(validationErrors) > 0 {
		return errors.New("validation errors: " + strings.Join(validationErrors, ", "))
	}
	return nil
}

// Save inserta una nueva orden de pago en la base de datos o actualiza una existente.
// En la implementación real, este método interactuaría con la base de datos.
func (o *Order) Save() error {
	// Implementación de guardado o actualización en base de datos
	return nil
}

// Cancel establece el estado de la orden de pago a "CANCELADA" y registra la fecha de actualización.
func (o *Order) Cancel() error {
	if o.Status == StatusReleased {
		return errors.New("cannot cancel a released order")
	}
	o.Status = StatusCancelled
	o.UpdatedAt = time.Now()
	return o.Save()
}

// Release establece el estado de la orden de pago a "LIBERADA" y registra la fecha de actualización.
func (o *Order) Release() error {
	if o.Status != StatusCaptured {
		return errors.New("only captured orders can be released")
	}
	o.Status = StatusReleased
	o.UpdatedAt = time.Now()
	return nil
}
