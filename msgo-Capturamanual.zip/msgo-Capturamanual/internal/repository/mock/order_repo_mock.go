package mock

import (
	"capturamanual/internal/model"
	"errors"
)

// MockOrderRepository es una implementación mock de OrderRepository.
type MockOrderRepository struct {
	Orders map[int64]*model.Order
	NextID int64
}

// NewMockOrderRepository crea una nueva instancia de MockOrderRepository.
func NewMockOrderRepository() *MockOrderRepository {
	return &MockOrderRepository{
		Orders: make(map[int64]*model.Order),
		NextID: 1,
	}
}

// Save inserta o actualiza una orden de pago en el mock.
func (m *MockOrderRepository) Save(order *model.Order) error {
	if order.ID == 0 {
		order.ID = m.NextID
		m.NextID++
	}
	m.Orders[order.ID] = order
	return nil
}

// GetByID devuelve una orden de pago por su ID del mock.
func (m *MockOrderRepository) GetByID(id int64) (*model.Order, error) {
	order, exists := m.Orders[id]
	if !exists {
		return nil, errors.New("order not found")
	}
	return order, nil
}

// List devuelve todas las órdenes de pago del mock.
func (m *MockOrderRepository) List() ([]*model.Order, error) {
	var orders []*model.Order
	for _, order := range m.Orders {
		orders = append(orders, order)
	}
	return orders, nil
}

// FindByCriteria devuelve órdenes de pago que coinciden con los criterios del mock.
func (m *MockOrderRepository) FindByCriteria(criteria *model.FilterCriteria) ([]*model.Order, error) {
	var orders []*model.Order
	for _, order := range m.Orders {
		if criteria.Matches(order) {
			orders = append(orders, order)
		}
	}
	return orders, nil
}

// Aquí puedes agregar cualquier otro método necesario para completar la interfaz OrderRepository.
