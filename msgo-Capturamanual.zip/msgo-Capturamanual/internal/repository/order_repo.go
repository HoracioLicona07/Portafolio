package repository

import (
	"capturamanual/internal/model"
	"database/sql"
	"fmt"
	"sync"
)

// OrderRepository define la interfaz para el repositorio de órdenes de pago.
type OrderRepository interface {
	Save(order *model.Order) error                                         // Guarda una orden de pago (inserta o actualiza).
	GetByID(id int64) (*model.Order, error)                                // Obtiene una orden de pago por su ID.
	List() ([]*model.Order, error)                                         // Lista todas las órdenes de pago.
	FindByCriteria(criteria *model.FilterCriteria) ([]*model.Order, error) // Filtra órdenes de pago según criterios.
}

// mockOrderDB simula una base de datos en memoria.
type mockOrderDB struct {
	sync.Mutex
	orders map[int64]*model.Order
	nextID int64
}

// NewMockOrderDB crea una nueva instancia de una base de datos en memoria.
func NewMockOrderDB() *mockOrderDB {
	return &mockOrderDB{
		orders: make(map[int64]*model.Order),
		nextID: 1,
	}
}

type sqlOrderRepository struct {
	db *sql.DB
}

// NewSQLOrderRepository crea un nuevo repositorio SQL.
func NewSQLOrderRepository(db *sql.DB) OrderRepository {
	return &sqlOrderRepository{
		db: db,
	}
}

// FindByCriteria busca órdenes que coincidan con los criterios de filtro dados.
func (r *sqlOrderRepository) FindByCriteria(criteria *model.FilterCriteria) ([]*model.Order, error) {
	// Aquí deberías implementar la lógica para filtrar las órdenes de pago en tu base de datos SQL.
	// Este es un ejemplo genérico de cómo podría ser esta función.

	// Construye la consulta SQL basada en los criterios de búsqueda.
	// Nota: Asegúrate de usar parámetros para prevenir inyecciones SQL.
	query := "SELECT * FROM orders WHERE 1=1"
	args := []interface{}{}

	// Agrega condiciones a la consulta basadas en los criterios no nulos
	if criteria.Number != "" {
		query += " AND number = ?"
		args = append(args, criteria.Number)
	}
	// ...agrega más condiciones para otros campos de criterios...

	// Prepara la sentencia SQL.
	stmt, err := r.db.Prepare(query)
	if err != nil {
		return nil, err
	}
	defer stmt.Close()

	// Ejecuta la consulta.
	rows, err := stmt.Query(args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	// Lee los resultados.
	var orders []*model.Order
	for rows.Next() {
		var order model.Order
		// Asegúrate de que el orden de escaneo coincida con el orden de las columnas en tu base de datos.
		if err := rows.Scan(&order.ID, &order.Number, &order.OperationDate, &order.Amount, &order.Status, &order.PaymentType, &order.BeneficiaryInstitution, &order.Priority, &order.Topology, &order.CreatedAt, &order.UpdatedAt); err != nil {
			return nil, err
		}
		orders = append(orders, &order)
	}

	// Comprueba si hubo errores durante el iterado.
	if err = rows.Err(); err != nil {
		return nil, err
	}

	return orders, nil
}

// GetByID busca una orden de pago por su ID.
func (r *sqlOrderRepository) GetByID(id int64) (*model.Order, error) {
	var order model.Order
	query := "SELECT id, number, operation_date, amount, status, payment_type, beneficiary_institution, priority, topology, created_at, updated_at FROM orders WHERE id = ?"
	row := r.db.QueryRow(query, id)

	err := row.Scan(&order.ID, &order.Number, &order.OperationDate, &order.Amount, &order.Status, &order.PaymentType, &order.BeneficiaryInstitution, &order.Priority, &order.Topology, &order.CreatedAt, &order.UpdatedAt)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, fmt.Errorf("order with ID %d not found", id)
		}
		return nil, err
	}

	return &order, nil
}

// List lista todas las órdenes de pago.
func (r *sqlOrderRepository) List() ([]*model.Order, error) {
	var orders []*model.Order
	query := "SELECT id, number, operation_date, amount, status, payment_type, beneficiary_institution, priority, topology, created_at, updated_at FROM orders"

	rows, err := r.db.Query(query)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	for rows.Next() {
		var order model.Order
		if err := rows.Scan(&order.ID, &order.Number, &order.OperationDate, &order.Amount, &order.Status, &order.PaymentType, &order.BeneficiaryInstitution, &order.Priority, &order.Topology, &order.CreatedAt, &order.UpdatedAt); err != nil {
			return nil, err
		}
		orders = append(orders, &order)
	}

	if err = rows.Err(); err != nil {
		return nil, err
	}

	return orders, nil
}

// Save inserta o actualiza una orden de pago en la base de datos SQL.
func (r *sqlOrderRepository) Save(order *model.Order) error {
	// Implementar lógica para insertar o actualizar la orden de pago en la base de datos SQL.
	// Esto es un ejemplo y debe ser adaptado a tu esquema de base de datos y lógica de negocio.

	// Si el ID de la orden es 0, entonces es una nueva orden y debe ser insertada.
	if order.ID == 0 {
		query := `INSERT INTO orders (number, operation_date, amount, status, payment_type, beneficiary_institution, priority, topology, created_at, updated_at) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
		res, err := r.db.Exec(query, order.Number, order.OperationDate, order.Amount, order.Status, order.PaymentType, order.BeneficiaryInstitution, order.Priority, order.Topology, order.CreatedAt, order.UpdatedAt)
		if err != nil {
			return err
		}

		id, err := res.LastInsertId()
		if err != nil {
			return err
		}
		order.ID = id
	} else {
		// Si el ID existe, entonces la orden debe ser actualizada.
		query := `UPDATE orders SET number=?, operation_date=?, amount=?, status=?, payment_type=?, beneficiary_institution=?, priority=?, topology=?, updated_at=? WHERE id=?`
		_, err := r.db.Exec(query, order.Number, order.OperationDate, order.Amount, order.Status, order.PaymentType, order.BeneficiaryInstitution, order.Priority, order.Topology, order.UpdatedAt, order.ID)
		if err != nil {
			return err
		}
	}

	return nil
}

// Save inserta o actualiza una orden de pago en la base de datos simulada.
func (db *mockOrderDB) Save(order *model.Order) error {
	db.Lock()
	defer db.Unlock()

	if order.ID == 0 {
		order.ID = db.nextID
		db.nextID++
	} else {
		_, exists := db.orders[order.ID]
		if !exists {
			return fmt.Errorf("order with ID %d does not exist", order.ID)
		}
	}

	db.orders[order.ID] = order
	return nil
}

// GetByID retorna una orden de pago por su ID de la base de datos simulada.
func (db *mockOrderDB) GetByID(id int64) (*model.Order, error) {
	db.Lock()
	defer db.Unlock()

	order, exists := db.orders[id]
	if !exists {
		return nil, fmt.Errorf("order with ID %d not found", id)
	}

	return order, nil
}

// List devuelve todas las órdenes de pago de la base de datos simulada.
func (db *mockOrderDB) List() ([]*model.Order, error) {
	db.Lock()
	defer db.Unlock()

	orders := make([]*model.Order, 0, len(db.orders))
	for _, order := range db.orders {
		orders = append(orders, order)
	}

	return orders, nil
}

// FindByCriteria busca órdenes que coincidan con los criterios de filtro dados.
func (db *mockOrderDB) FindByCriteria(criteria *model.FilterCriteria) ([]*model.Order, error) {
	db.Lock()
	defer db.Unlock()

	filteredOrders := make([]*model.Order, 0)
	for _, order := range db.orders {
		if criteria.Matches(order) { // Asumiendo que Matches es un método en FilterCriteria
			filteredOrders = append(filteredOrders, order)
		}
	}

	return filteredOrders, nil
}

//otros métodos
