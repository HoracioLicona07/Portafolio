package service

import (
	"capturamanual/internal/model"
	"capturamanual/internal/repository"
	"fmt"
	"time"
)

// CancelService representa un servicio para manejar la cancelación de órdenes de pago.
type CancelService struct {
	orderRepo repository.OrderRepository
}

// NewCancelService crea un nuevo servicio para cancelar órdenes de pago.
func NewCancelService(repo repository.OrderRepository) *CancelService {
	return &CancelService{
		orderRepo: repo,
	}
}

// CancelOrder maneja la lógica de negocio para cancelar una orden de pago existente.
func (s *CancelService) CancelOrder(orderID int64) error {
	// Obtener la orden de pago existente por su ID.
	order, err := s.orderRepo.GetByID(orderID)
	if err != nil {
		return fmt.Errorf("error retrieving order: %w", err)
	}

	// Verificar si la orden de pago puede ser cancelada según las reglas de negocio.
	if order.Status != model.StatusCaptured {
		return fmt.Errorf("order with status %s cannot be cancelled", order.Status)
	}

	// Actualizar el estado de la orden de pago a "Cancelada".
	order.Status = model.StatusCancelled
	order.UpdatedAt = time.Now() // Usar time.Now() para obtener la hora actual.

	// Persistir los cambios en el repositorio de órdenes de pago.
	if err := s.orderRepo.Save(order); err != nil {
		return fmt.Errorf("error saving cancelled order: %w", err)
	}

	return nil
}

// Aquí puedes añadir más métodos relacionados con la cancelación de órdenes de pago si es necesario.
