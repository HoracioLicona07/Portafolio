package service

import (
	"capturamanual/internal/model"
	"capturamanual/internal/repository"
	"fmt"
)

// CaptureService representa un servicio para manejar la captura de órdenes de pago.
type CaptureService struct {
	orderRepo repository.OrderRepository
}

// NewCaptureService crea un nuevo servicio para capturar órdenes de pago.
func NewCaptureService(repo repository.OrderRepository) *CaptureService {
	return &CaptureService{
		orderRepo: repo,
	}
}

// CaptureOrder maneja la lógica de negocio para capturar una nueva orden de pago.
func (s *CaptureService) CaptureOrder(order *model.Order) (*model.Order, error) {
	// Validar la orden de pago.
	if err := order.Validate(); err != nil {
		return nil, fmt.Errorf("validation failed: %w", err)
	}

	// Guardar la orden de pago en el repositorio.
	if err := s.orderRepo.Save(order); err != nil {
		return nil, fmt.Errorf("failed to save the order: %w", err)
	}

	return order, nil
}

// Aquí puedes añadir más métodos relacionados con la captura de órdenes de pago si es necesario.
