package service

import (
	"capturamanual/internal/model"
	"capturamanual/internal/repository"
	"fmt"
)

type FilterService struct {
	orderRepo repository.OrderRepository
}

func NewFilterService(repo repository.OrderRepository) *FilterService {
	return &FilterService{
		orderRepo: repo,
	}
}

func (s *FilterService) FilterOrders(criteria *model.FilterCriteria) ([]*model.Order, error) {
	// Aquí implementarías la lógica para filtrar las órdenes de pago basadas en los criterios dados.
	// Esto es un ejemplo y debe ser completado con la lógica de negocio correspondiente.

	// Llamada correcta al método FindByCriteria del repositorio.
	orders, err := s.orderRepo.FindByCriteria(criteria)
	if err != nil {
		return nil, fmt.Errorf("error filtering orders: %w", err)
	}

	return orders, nil
}
