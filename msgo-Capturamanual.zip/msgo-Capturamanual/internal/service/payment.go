package service

import (
	"capturamanual/internal/model"
	"capturamanual/internal/repository"
	"log"
	// Considera importar paquetes para logging, manejo de errores, etc.
)

// PaymentService es una estructura que maneja las operaciones de negocio de las órdenes de pago.
type PaymentService struct {
	orderRepo repository.OrderRepository // La interfaz para el repositorio de órdenes de pago.
}

// NewPaymentService crea una nueva instancia de PaymentService.
func NewPaymentService(repo repository.OrderRepository) *PaymentService {
	return &PaymentService{
		orderRepo: repo,
	}
}

// CaptureOrder maneja la captura de una nueva orden de pago.
func (s *PaymentService) CaptureOrder(number string, amount float64, paymentType, beneficiaryInstitution, priority, topology string) (*model.Order, error) {
	// Realiza cualquier validación adicional si es necesario
	order, err := model.NewOrder(number, amount, paymentType, beneficiaryInstitution, priority, topology)
	if err != nil {
		// Considera utilizar un paquete de manejo de errores para errores más descriptivos.
		log.Printf("Error creating new order: %v", err)
		return nil, err
	}

	// Guardar la nueva orden utilizando el repositorio.
	if err = s.orderRepo.Save(order); err != nil {
		log.Printf("Error saving new order: %v", err)
		return nil, err
	}

	return order, nil
}

// ReleaseOrder maneja la liberación de una orden de pago capturada.
func (s *PaymentService) ReleaseOrder(orderID int64) error {
	order, err := s.orderRepo.GetByID(orderID)
	if err != nil {
		log.Printf("Error retrieving order: %v", err)
		return err
	}

	if err = order.Release(); err != nil {
		log.Printf("Error releasing order: %v", err)
		return err
	}

	if err = s.orderRepo.Save(order); err != nil {
		log.Printf("Error saving released order: %v", err)
		return err
	}

	return nil
}

// CancelOrder maneja la cancelación de una orden de pago.
func (s *PaymentService) CancelOrder(orderID int64) error {
	order, err := s.orderRepo.GetByID(orderID)
	if err != nil {
		log.Printf("Error retrieving order: %v", err)
		return err
	}

	if err = order.Cancel(); err != nil {
		log.Printf("Error canceling order: %v", err)
		return err
	}

	if err = s.orderRepo.Save(order); err != nil {
		log.Printf("Error saving canceled order: %v", err)
		return err
	}

	return nil
}

// Aquí puedes añadir más métodos que manejen otras lógicas de negocio, como la suma de órdenes de pago, actualizaciones, etc.
// Considere implementar métodos adicionales aquí.
