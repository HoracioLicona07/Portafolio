package service

import (
	"capturamanual/internal/model"
	"capturamanual/internal/repository"
	"fmt"
	"time"
)

// ReleaseService representa un servicio para manejar la liberación de órdenes de pago.
type ReleaseService struct {
	orderRepo repository.OrderRepository
}

// NewReleaseService crea un nuevo servicio para la liberación de órdenes de pago.
func NewReleaseService(repo repository.OrderRepository) *ReleaseService {
	return &ReleaseService{
		orderRepo: repo,
	}
}

// ReleaseOrder maneja la lógica de negocio para liberar una orden de pago existente.
func (s *ReleaseService) ReleaseOrder(orderID int64) error {
	// Obtener la orden de pago existente por su ID.
	order, err := s.orderRepo.GetByID(orderID)
	if err != nil {
		return fmt.Errorf("error retrieving order: %w", err)
	}

	// Verificar si la orden de pago puede ser liberada según las reglas de negocio.
	if order.Status != model.StatusCaptured {
		return fmt.Errorf("order with status %s cannot be released", order.Status)
	}

	// Aquí podrías añadir lógica adicional para manejar certificados si es necesario.

	// Actualizar el estado de la orden de pago a "Liberada".
	order.Status = model.StatusReleased
	order.UpdatedAt = time.Now() // Asegúrate de utilizar la implementación adecuada para obtener la hora actual.

	// Persistir los cambios en el repositorio de órdenes de pago.
	if err := s.orderRepo.Save(order); err != nil {
		return fmt.Errorf("error saving released order: %w", err)
	}

	return nil
}

// Aquí puedes añadir más métodos relacionados con la liberación de órdenes de pago si es necesario.
