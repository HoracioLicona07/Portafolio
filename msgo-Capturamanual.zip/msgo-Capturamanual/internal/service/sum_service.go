package service

import (
	"capturamanual/internal/repository"
	"fmt"
)

// SumService representa un servicio para sumar importes de órdenes de pago.
type SumService struct {
	orderRepo repository.OrderRepository
}

// NewSumService crea un nuevo servicio para sumar órdenes de pago.
func NewSumService(repo repository.OrderRepository) *SumService {
	return &SumService{
		orderRepo: repo,
	}
}

// SumOrders suma el importe de las órdenes de pago dentro de un rango específico.
func (s *SumService) SumOrders(startID, endID int64) (float64, error) {
	// Asegúrate de que los IDs proporcionados son válidos y que startID no es mayor que endID.
	if startID > endID {
		return 0, fmt.Errorf("startID must be less than or equal to endID")
	}

	// Obtener la lista de órdenes de pago.
	orders, err := s.orderRepo.List()
	if err != nil {
		return 0, fmt.Errorf("error retrieving orders: %w", err)
	}

	// Sumar los importes de las órdenes de pago que están dentro del rango.
	var sum float64
	for _, order := range orders {
		if order.ID >= startID && order.ID <= endID {
			sum += order.Amount
		}
	}

	return sum, nil
}

// Aquí puedes añadir más métodos relacionados con la suma de órdenes de pago si es necesario.
