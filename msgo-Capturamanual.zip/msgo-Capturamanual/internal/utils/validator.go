package utils

import (
	"capturamanual/internal/model"
	"errors"
	"strings"
)

// ValidateOrder verifica que la orden de pago tenga todos los campos requeridos con los formatos y valores correctos.
func ValidateOrder(order *model.Order) error {
	var validationErrors []string

	// Validar el número de la orden.
	if strings.TrimSpace(order.Number) == "" {
		validationErrors = append(validationErrors, "number is required")
	}

	// Validar el importe de la orden.
	if order.Amount <= 0 {
		validationErrors = append(validationErrors, "amount must be positive")
	}

	// Validar el tipo de pago.
	if strings.TrimSpace(order.PaymentType) == "" {
		validationErrors = append(validationErrors, "payment type is required")
	}

	// Validar la institución beneficiaria.
	if strings.TrimSpace(order.BeneficiaryInstitution) == "" {
		validationErrors = append(validationErrors, "beneficiary institution is required")
	}

	// Validar la prioridad.
	if strings.TrimSpace(order.Priority) == "" {
		validationErrors = append(validationErrors, "priority is required")
	}

	// Validar la topología.
	if strings.TrimSpace(order.Topology) == "" {
		validationErrors = append(validationErrors, "topology is required")
	}

	// Añadir más validaciones según sean necesarias.

	if len(validationErrors) > 0 {
		return errors.New("validation errors: " + strings.Join(validationErrors, ", "))
	}

	return nil
}

// Add any additional validation functions below.
