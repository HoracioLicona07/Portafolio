package configs

import (
	"fmt"
	"os"
	"strconv"
)

// Config estructura para mantener la configuración de la aplicación.
type Config struct {
	ServerAddress string // Dirección y puerto en el que se ejecutará el servidor, por ejemplo, ":8080".
	DatabaseDSN   string // Data Source Name para la conexión a la base de datos, no debe tener un valor predeterminado.
	// Agrega aquí cualquier otro campo de configuración que necesites.
}

// LoadConfig carga la configuración desde las variables de entorno.
// Devuelve un error si alguna configuración requerida no está presente o es inválida.
func LoadConfig() (*Config, error) {
	cfg := &Config{
		ServerAddress: getEnv("SERVER_ADDRESS", ":8080"), // Un puerto predeterminado es aceptable para SERVER_ADDRESS.
	}

	// DATABASE_DSN es crítico y no debe tener un valor predeterminado.
	var err error
	cfg.DatabaseDSN, err = mustGetEnv("DATABASE_DSN")
	if err != nil {
		return nil, fmt.Errorf("error loading config for DATABASE_DSN: %w", err)
	}

	// Incluye aquí la carga y validación de cualquier otra configuración que necesites.

	return cfg, nil // Esta es la línea de retorno correcta para la función LoadConfig.
}

// getEnv busca una variable de entorno y devuelve su valor o un valor predeterminado.
func getEnv(key, defaultValue string) string {
	if value, exists := os.LookupEnv(key); exists {
		return value
	}
	return defaultValue
}

// mustGetEnv busca una variable de entorno y devuelve su valor o un error si no está presente.
func mustGetEnv(key string) (string, error) {
	if value, exists := os.LookupEnv(key); exists {
		return value, nil
	}
	return "", fmt.Errorf("environment variable %s not set", key)
}

// getIntEnv obtiene una variable de entorno como un entero o devuelve un valor por defecto.
func getIntEnv(key string, defaultValue int) (int, error) {
	valueStr, exists := os.LookupEnv(key)
	if !exists {
		return defaultValue, nil
	}

	value, err := strconv.Atoi(valueStr)
	if err != nil {
		return 0, fmt.Errorf("environment variable %s should be an integer: %v", key, err)
	}

	return value, nil
}

// Aquí podrías agregar más funciones de ayuda para cargar diferentes tipos de datos (bools, slices, etc.).
