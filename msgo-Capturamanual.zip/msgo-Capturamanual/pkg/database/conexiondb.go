package database

import (
	"database/sql"
	"fmt"
	"log"

	_ "github.com/denisenkom/go-mssqldb"
)

func ConectarSQLServer() (*sql.DB, error) {
	server := Get("DBSERVER", "localhost")
	port := Get("DBPORT", "1433")
	user := Get("DBUSER", "")
	password := Get("DBPASSWORD", "")
	database := Get("DBDATABASE", "EKARPAY")

	// Verificar que las configuraciones esenciales no estén vacías
	if server == "" || port == "" || database == "" {
		log.Fatal("Faltan configuraciones esenciales de la base de datos")
	}

	// Establecer la cadena de conexión
	var connString string
	if user != "" && password != "" {
		connString = fmt.Sprintf("server=%s;user id=%s;password=%s;port=%s;database=%s", server, user, password, port, database)
	} else {
		connString = fmt.Sprintf("server=%s;port=%s;database=%s;trusted_connection=yes", server, port, database)
	}

	// Abre la conexión
	db, err := sql.Open("sqlserver", connString)
	if err != nil {
		return nil, fmt.Errorf("Error al abrir la conexión: %v", err)
	}

	// Intenta conectar
	err = db.Ping()
	if err != nil {
		return nil, fmt.Errorf("Error al conectar con la base de datos: %v", err)
	}

	fmt.Println("Conexión exitosa a SQL Server")
	return db, nil
}
