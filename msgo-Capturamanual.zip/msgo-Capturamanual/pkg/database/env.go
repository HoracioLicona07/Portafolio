package database

import (
	"log"
	"os"

	"github.com/joho/godotenv"
)

// init se llama automáticamente al inicializar el paquete.
func init() {
	// Carga el archivo .env.
	err := godotenv.Load()
	if err != nil {
		log.Fatal("Error al cargar el archivo .env: ", err)
	}
}

// Get obtiene una variable de entorno o devuelve un valor predeterminado.
func Get(key, defaultValue string) string {
	if value, exists := os.LookupEnv(key); exists {
		return value
	}
	log.Printf("Variable de entorno '%s' no establecida. Usando valor por defecto: '%s'\n", key, defaultValue)
	return defaultValue
}
