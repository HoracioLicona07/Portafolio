#!/bin/bash

# Detener la ejecución si ocurre un error
set -e

# Definir variables
DOCKER_IMAGE="capturamanual/payment-service"
DOCKER_TAG="latest"
DOCKER_REGISTRY="tu_registro_docker"

# Paso 1: Construir la imagen Docker
echo "Construyendo imagen Docker..."
docker build -t $DOCKER_IMAGE:$DOCKER_TAG .

# (Opcional) Paso 2: Ejecutar pruebas
# echo "Ejecutando pruebas..."
# Comandos para ejecutar pruebas

# Paso 3: Etiquetar la imagen Docker
echo "Etiquetando imagen Docker..."
docker tag $DOCKER_IMAGE:$DOCKER_TAG $DOCKER_REGISTRY/$DOCKER_IMAGE:$DOCKER_TAG

# Paso 4: Subir la imagen al registro Docker
echo "Subiendo imagen a Docker Registry..."
docker push $DOCKER_REGISTRY/$DOCKER_IMAGE:$DOCKER_TAG

# Paso 5: Desplegar en el entorno de producción/staging
# Aquí puedes usar herramientas como Kubernetes, Docker Swarm, etc.
# Ejemplo:
# kubectl set image deployment/payment-service payment-service=$DOCKER_REGISTRY/$DOCKER_IMAGE:$DOCKER_TAG

echo "Despliegue completado."
