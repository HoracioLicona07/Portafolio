#!/bin/bash

# Detener la ejecución si ocurre un error
set -e

# Establecer variables de entorno básicas para la aplicación
export DB_HOST="host_de_tu_base_de_datos"
export DB_PORT="puerto_de_tu_base_de_datos"
export DB_NAME="nombre_de_tu_base_de_datos"
export DB_USER="usuario_de_tu_base_de_datos"
export DB_PASSWORD="contraseña_de_tu_base_de_datos"

export SERVER_PORT="8080"
export LOG_LEVEL="info" # Puede ser debug, info, warning, error, etc.

# (Opcional) Configuraciones específicas de tu aplicación
# Por ejemplo, si estás usando un servicio externo, puedes configurar sus credenciales aquí
# export EXTERNAL_SERVICE_API_KEY="tu_api_key"

# (Opcional) Mensaje de configuración
echo "Entorno configurado correctamente."

# (Opcional) Ejecutar cualquier script de preparación adicional, como migraciones de base de datos
# ./migrate.sh

# Nota: este script solo establece variables de entorno para la sesión actual del shell.
# Si necesitas que estas variables estén disponibles globalmente o en otra sesión,
# considera añadirlas a tu archivo .bashrc, .bash_profile, o .profile dependiendo de tu sistema
