package api_test

import (
	"bytes"
	"capturamanual/internal/api"
	"capturamanual/internal/model"
	"capturamanual/internal/repository/mock"
	"capturamanual/internal/service"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
)

// Helper para crear un servidor HTTP de prueba y un cliente.
func setup() (*http.ServeMux, *httptest.Server) {
	mux := http.NewServeMux()
	server := httptest.NewServer(mux)
	return mux, server
}

// TestCaptureHandler para probar el manejador de captura de órdenes de pago.
func TestCaptureHandler(t *testing.T) {
	// Configurar el entorno de prueba
	orderRepo := mock.NewMockOrderRepository()
	captureService := service.NewCaptureService(orderRepo)
	captureHandler := api.NewCaptureHandler(captureService)

	mux, server := setup()
	defer server.Close()

	// Configurar rutas
	captureHandler.SetupRoutes(mux)

	// Crear solicitud HTTP de prueba
	orderRequest := model.Order{
		// Rellenar con datos de prueba
	}
	body, _ := json.Marshal(orderRequest)
	req, _ := http.NewRequest("POST", server.URL+"/orders/capture", bytes.NewBuffer(body))

	// Ejecutar la solicitud
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("Failed to send request: %v", err)
	}
	defer resp.Body.Close()

	// Verificar el resultado
	if resp.StatusCode != http.StatusCreated {
		t.Errorf("Expected status code %d, got %d", http.StatusCreated, resp.StatusCode)
	}

	// Realizar más verificaciones según sea necesario
}

// Funciones de prueba adicionales para otros manejadores...

// TestReleaseHandler, TestCancelHandler, TestSumHandler, TestFilterHandler, etc.
