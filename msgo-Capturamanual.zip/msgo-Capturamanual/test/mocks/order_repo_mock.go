package mocks

import (
	"capturamanual/internal/model"
	"sync"
)

// MockOrderRepository es una simulación del repositorio de órdenes de pago.
type MockOrderRepository struct {
	sync.Mutex
	orders map[int64]*model.Order
	nextID int64
}

// NewMockOrderRepository crea una nueva instancia de MockOrderRepository.
func NewMockOrderRepository() *MockOrderRepository {
	return &MockOrderRepository{
		orders: make(map[int64]*model.Order),
		nextID: 1,
	}
}

// Save inserta o actualiza una orden de pago en el repositorio mock.
func (m *MockOrderRepository) Save(order *model.Order) error {
	m.Lock()
	defer m.Unlock()

	if order.ID == 0 {
		order.ID = m.nextID
		m.nextID++
	}
	m.orders[order.ID] = order

	return nil
}

// GetByID retorna una orden de pago por su ID del repositorio mock.
func (m *MockOrderRepository) GetByID(id int64) (*model.Order, error) {
	m.Lock()
	defer m.Unlock()

	order, exists := m.orders[id]
	if !exists {
		return nil, nil // O devuelve un error si prefieres simular que no se encontró
	}

	return order, nil
}

// List retorna todas las órdenes de pago del repositorio mock.
func (m *MockOrderRepository) List() ([]*model.Order, error) {
	m.Lock()
	defer m.Unlock()

	var orders []*model.Order
	for _, order := range m.orders {
		orders = append(orders, order)
	}

	return orders, nil
}

// FindByCriteria busca órdenes que coincidan con los criterios de filtro dados en el repositorio mock.
func (m *MockOrderRepository) FindByCriteria(criteria *model.FilterCriteria) ([]*model.Order, error) {
	m.Lock()
	defer m.Unlock()

	var filteredOrders []*model.Order
	for _, order := range m.orders {
		if criteria.Matches(order) {
			filteredOrders = append(filteredOrders, order)
		}
	}

	return filteredOrders, nil
}

// Aquí puedes agregar más métodos mock según sea necesario.
