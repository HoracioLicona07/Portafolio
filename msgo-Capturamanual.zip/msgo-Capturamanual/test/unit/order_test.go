package model_test

import (
	"capturamanual/internal/model"
	"testing"
	"time"
)

func TestNewOrder(t *testing.T) {
	// Datos de prueba
	number := "12345"
	amount := 100.50
	paymentType := "TRANSFERENCIA"
	beneficiaryInstitution := "BANCOX"
	priority := "ALTA"
	topology := "NACIONAL"

	// Creación de una nueva orden de pago
	order, err := model.NewOrder(number, amount, paymentType, beneficiaryInstitution, priority, topology)
	if err != nil {
		t.Errorf("Error al crear una nueva orden: %v", err)
	}

	// Verificaciones básicas
	if order.Number != number {
		t.Errorf("Número de orden incorrecto, se esperaba %s, se obtuvo %s", number, order.Number)
	}
	// ... Más verificaciones ...
}

func TestOrderValidate(t *testing.T) {
	// Crear una instancia de Order con datos válidos
	order := model.Order{
		Number:                 "12345",
		OperationDate:          time.Now(),
		Amount:                 100.50,
		Status:                 model.StatusCaptured,
		PaymentType:            "TRANSFERENCIA",
		BeneficiaryInstitution: "BANCOX",
		Priority:               "ALTA",
		Topology:               "NACIONAL",
	}

	// Validar la orden
	err := order.Validate()
	if err != nil {
		t.Errorf("La validación de la orden falló cuando se esperaba que fuera correcta: %v", err)
	}

	// Cambiar a datos no válidos y probar nuevamente
	order.Amount = -50.00
	err = order.Validate()
	if err == nil {
		t.Error("La validación de la orden no falló cuando se esperaba un error")
	}
}

// ... Más pruebas unitarias para otras funcionalidades de la entidad Order ...
