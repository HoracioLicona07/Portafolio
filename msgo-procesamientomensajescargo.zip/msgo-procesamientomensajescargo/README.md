# MSGO-ProcesamientoMensajesCargo
### Example message correct
3er (mandar mensajes)``{"FolioOrden":12345,"FolioPaquete":67890,"FechaOperacion":"2023-09-14T10:00:00","Monto":"1250.75","IDTipoPago":1,"ClaveRastreo":"ABCD123456","ClaveBeneficiario":null,"FirmaDigitalKarpay":"Ae9i0n84jcqzGqRg6LtvjDJGnE9gGzo7e7OQd39k5h0=","IDEstado":2}``

### Example message incorrect
3ro (mensaje incorrecto)``{"FolioOrden":0000,"FolioPaquete":67890,"FechaOperacion":"2023-09-14T10:00:00","Monto":"1250.75","IDTipoPago":1,"ClaveRastreo":"ABCD123456","ClaveBeneficiario":null,"FirmaDigitalKarpay":"a=","IDEstado":2}``

##Crear topicos
kafka-topics.sh --create --zookeeper zookeeper:2181 --replication-factor 1 --partitions 1 --topic procesamientoMensajesCargoEnviados

kafka-topics.sh --create --zookeeper zookeeper:2181 --replication-factor 1 --partitions 1 --topic procesamientoMensajesCargo

### To do MSGO-procesamientoMensajesCargo
1er``docker exec -it kafka /bin/sh``

2do(mandar mensajes)``kafka-console-producer.sh --topic procesamientoMensajesCargo --bootstrap-server localhost:9092``

2do (recibir mensajes correctos)``kafka-console-consumer.sh --topic procesamientoMensajesCargoEnviados --from-beginning --bootstrap-server localhost:9092``

``kafka-topics --list --bootstrap-server localhost:9092``