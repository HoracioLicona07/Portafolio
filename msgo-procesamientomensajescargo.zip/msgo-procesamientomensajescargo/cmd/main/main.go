package main

import (
	"fmt"

	"192.168.1.46/gitlab/e-karpay-code/karpay_10/msgo-procesamientomensajescargo/-/tree/Develop/internal/db"
	"192.168.1.46/gitlab/e-karpay-code/karpay_10/msgo-procesamientomensajescargo/-/tree/Develop/internal/envs"
	"192.168.1.46/gitlab/e-karpay-code/karpay_10/msgo-procesamientomensajescargo/-/tree/Develop/internal/services"
	"github.com/IBM/sarama"
)

func main() {
	// Conexión a la base de datos
	database, errdb := db.ConectarSQLServer()
	if errdb != nil {
		fmt.Println("Error al conectar a SQL Server:", errdb)
		return
	}

	// Cierra la conexión cuando ya no se necesite
	defer database.Close()

	// Configuración de Kafka
	kafkaConfig := sarama.NewConfig()
	kafkaConfig.Consumer.Return.Errors = true

	// Crear una instancia del servicio
	servicio := services.ProcesamientoCargosServiceImpl{
		PosInicial:    0,
		TopicReply:    envs.Get("TOPICENTRY", "topico"),
		PathToSend:    "",
		NumberRetries: 3,
		KafkaConfig:   kafkaConfig,
	}

	/// Inicializa la conexión a Kafka
	err := servicio.InitKafka()
	if err != nil {
		fmt.Println("Error al inicializar Kafka:", err)
		return
	}

	// Inicia el consumo de mensajes de Kafka
	servicio.ConsumeMensajesKafka()
}
