package db

import (
	"database/sql"
	"fmt"

	"192.168.1.46/gitlab/e-karpay-code/karpay_10/msgo-procesamientomensajescargo/-/tree/Develop/internal/envs"
	_ "github.com/denisenkom/go-mssqldb"
)

func ConectarSQLServer() (*sql.DB, error) {
	// Establece la cadena de conexión
	connString := fmt.Sprintf("server=%s;port=%s;database=%s;trusted_connection=yes;", envs.Get("DBSERVER", "server"), envs.Get("DBPORT", "port"), envs.Get("DBDATABASE", "db"))

	// Abre la conexión
	db, err := sql.Open("sqlserver", connString)
	if err != nil {
		return nil, err
	}

	// Intenta conectar
	err = db.Ping()
	if err != nil {
		return nil, err
	}

	fmt.Println("Conexión exitosa a SQL Server")
	return db, nil
}
