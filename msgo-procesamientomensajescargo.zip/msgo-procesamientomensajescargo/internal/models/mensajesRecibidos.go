package models

import (
	"time"

	"gorm.io/gorm"
)

type MensajesRecibidosEntity struct {
	gorm.Model
	IDMensaje             int       `gorm:"column:idmensaje;primaryKey;autoIncrement"`
	Tipo                  string    `gorm:"column:tipo;not null"`
	EtiquetaTiempo        int64     `gorm:"column:etiquetatiempo;not null"`
	FechaOperacion        time.Time `gorm:"column:fechaoperacion;not null"`
	FolioServidor         int       `gorm:"column:folioservidor;not null"`
	CtaBytesInicio        float64   `gorm:"column:ctabytesinicio;not null"`
	CtaBytesFin           float64   `gorm:"column:ctabytesfin;not null"`
	NuevoSaldoReservado   float64   `gorm:"column:nuevosaldoreservado;not null"`
	NuevoSaldoNoReservado float64   `gorm:"column:nuevosaldonoreservado;not null"`
	NuevoSaldoTotal       float64   `gorm:"column:nuevosaldototal;not null"`
	IDEstadoCORE          int       `gorm:"column:idestadocore;not null"`
	HoraNotificacionCORE  time.Time `gorm:"column:horanotificacincore;not null"`
}
