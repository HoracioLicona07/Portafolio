package models

import (
	"time"

	"gorm.io/gorm"
)

type OrdenesPagoEnvioEntity struct {
	gorm.Model
	IDOrden                         int       `gorm:"column:idorden;primaryKey;autoIncrement"`
	EtiquetaTiempoCaptura           int64     `gorm:"column:etiquetatiempocaptura"`
	FechaOperacion                  time.Time `gorm:"column:fechaoperacion"`
	Monto                           float64   `gorm:"column:monto"`
	Prioridad                       int       `gorm:"column:prioridad"`
	IDTipoPago                      int       `gorm:"column:idtipopago"`
	ClaveRastreo                    string    `gorm:"column:claverastreo"`
	IDMedioEntrega                  int       `gorm:"column:idmedioentrega"`
	NombreOrdenante                 string    `gorm:"column:nombreordenante"`
	TipoCuentaOrdenante             int       `gorm:"column:tipocuentaordenante"`
	CuentaOrdenante                 string    `gorm:"column:cuentaordenante"`
	RFCOrdenante                    string    `gorm:"column:rfcordenante"`
	CURPOrdenante                   string    `gorm:"column:curpordenante"`
	ClaveBeneficiario               int       `gorm:"column:clavebeneficiario"`
	NombreBeneficiario              string    `gorm:"column:nombrebeneficiario"`
	TipoCuentaBeneficiario          int       `gorm:"column:tipocuentabeneficiario"`
	CuentaBeneficiario              string    `gorm:"column:cuentabeneficiario"`
	RFCBeneficiario                 string    `gorm:"column:rfcbeneficiario"`
	CURPBeneficiario                string    `gorm:"column:curpbeneficiario"`
	ConceptoPago40                  string    `gorm:"column:conceptopago40"`
	ConceptoPago210                 string    `gorm:"column:conceptopago210"`
	ImporteIVA                      float64   `gorm:"column:importeiva"`
	ReferenciaNumerica              int       `gorm:"column:referencianumerica"`
	ReferenciaCobranza1             string    `gorm:"column:referenciacobranza1"`
	ClavePago                       string    `gorm:"column:clavepago"`
	NombreBeneficiario2             string    `gorm:"column:nombrebeneficiario2"`
	TipoCuentaBeneficiario2         int       `gorm:"column:tipocuentabeneficiario2"`
	CuentaBeneficiario2             string    `gorm:"column:cuentabeneficiario2"`
	RFCBeneficiario2                string    `gorm:"column:rfcbeneficiario2"`
	CURPBeneficiario2               string    `gorm:"column:curpbeneficiario2"`
	IDTipoOperacion                 int       `gorm:"column:idtipooperacion"`
	IDCausaDevolucion               int       `gorm:"column:idcausadevolucion"`
	InformacionFacturas             string    `gorm:"column:informacionfacturas"`
	FolioInstruccionOriginal        int       `gorm:"column:folioinstruccionoriginal"`
	FolioPagoOriginal               int       `gorm:"column:foliopagooriginal"`
	FechaOrdenTransferenciaOriginal time.Time `gorm:"column:fechaordentransferenciaoriginal"`
	ClaveRastreoPagoOriginal        string    `gorm:"column:claverastreopagorig"`
	RefernciaNumPagoOriginal        int       `gorm:"column:referencianumpagorig"`
	TipoCtaOrdenantePagoOriginal    int       `gorm:"column:tipoctaordenantepagorig"`
	CtaOrdenantePagoOriginal        string    `gorm:"column:ctaordenantepagorig"`
	ConceptoPagoOriginal            string    `gorm:"column:conceptopagorig"`
	MontoPagoOriginal               float64   `gorm:"column:montopagorig"`
	MontoInteresesPagados           float64   `gorm:"column:montointeresespagados"`
	IndicadorBeneficiarioRecursos   int       `gorm:"column:indicadorbeneficiariorecursos"`
	NumCelOrdenante                 string    `gorm:"column:numcelordenante"`
	DigitoVerifDispoOrdenante       int       `gorm:"column:digitoverifdispoordenante"`
	NumCelBeneficiario              string    `gorm:"column:numcelbeneficiario"`
	DigitoVerifDispoBeneficiario    int       `gorm:"column:digitoverifdispobeneficiario"`
	FolioEsquemaCobroDigital        string    `gorm:"column:folioesqcobrodigital"`
	PagoComisionporTransferencia    int       `gorm:"column:pagocomisionportransferencia"`
	MontoComisionporTransferncia    float64   `gorm:"column:montocomisionportransferencia"`
	NumSerieCertificaddoEnvio       string    `gorm:"column:numseriecertificadoenvio"`
	FechaLimitePago                 time.Time `gorm:"column:fechalimitepago"`
	UETRSwift                       string    `gorm:"column:uetrswift"`
	CampoSwift1                     string    `gorm:"column:camposwift1"`
	CampoSwift2                     string    `gorm:"column:camposwift2"`
	HuellaDigital                   string    `gorm:"column:huelladigital"`
	FirmaDigitalCliente             string    `gorm:"column:firmadigitalcliente"`
	IDUsuarioCaptura                int       `gorm:"column:idusuariocaptura"`
	IDInstruccionPago               int       `gorm:"column:idinstruccionpago"`
	FolioOrdenInstruccion           int       `gorm:"column:folioordeninstruccion"`
	IDEstadoCore                    int       `gorm:"column:idestadocore"`
	IDEstadoBMX                     int       `gorm:"column:idestadobmx"`
}
