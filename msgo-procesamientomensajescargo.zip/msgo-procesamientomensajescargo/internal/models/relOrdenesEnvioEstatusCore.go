package models

import (
	"gorm.io/gorm"
)

type RelOrdenesEnvioEstatusCoreEntity struct {
	gorm.Model
	IDRelacion     int   `gorm:"column:idrelacion;primaryKey;autoIncrement"`
	IDUsuario      int   `gorm:"column:idusuario;not null"`
	IDEstado       int   `gorm:"column:idestado;not null"`
	IDOrdenPago    int   `gorm:"column:idordenpago;not null"`
	EtiquetaTiempo int64 `gorm:"column:etiquetatiempo;not null"`
}
