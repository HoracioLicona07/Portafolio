package services

import "192.168.1.46/gitlab/e-karpay-code/karpay_10/msgo-procesamientomensajescargo/-/tree/Develop/internal/vo"

// Definición de la interfaz ProcesamientoCargosService
type ProcesamientoCargosService interface {
	// Método para procesar cargos
	ProcesCargo(cargos vo.WrapperNotificacionVO) interface{}

	// Método para leer e interpretar un byte array de cargos
	ProcesaByteArray(obj vo.MensajesCargoVO, cargos vo.WrapperNotificacionVO) vo.MensajesCargoVO

	// Método para procesar la respuesta del envío al core y actualizar el estatus
	ProcessRespuestaCore(abonos []vo.NotificacionCargosVO) interface{}
}
