package services

import (
	"encoding/base64"
	"encoding/json"
	"fmt"

	"192.168.1.46/gitlab/e-karpay-code/karpay_10/msgo-procesamientomensajescargo/-/tree/Develop/internal/envs"
	"192.168.1.46/gitlab/e-karpay-code/karpay_10/msgo-procesamientomensajescargo/-/tree/Develop/internal/vo"
	"github.com/IBM/sarama"
)

type ProcesamientoCargosServiceImpl struct {
	PosInicial    int
	TopicReply    string
	PathToSend    string
	NumberRetries int
	KafkaConfig   *sarama.Config
	Producer      sarama.SyncProducer
	Consumer      sarama.Consumer
}

// Función para inicializar la conexión a Kafka
func (s *ProcesamientoCargosServiceImpl) InitKafka() error {
	var err error

	// Configurar el productor de Kafka
	s.KafkaConfig.Producer.Return.Successes = true
	s.Producer, err = sarama.NewSyncProducer([]string{"127.0.0.1:9092"}, s.KafkaConfig)
	if err != nil {
		return err
	}

	// Configurar el consumidor de Kafka
	s.Consumer, err = sarama.NewConsumer([]string{"127.0.0.1:9092"}, s.KafkaConfig)
	if err != nil {
		return err
	}

	return nil
}

// Función para consumir mensajes de un tópico de Kafka
func (s *ProcesamientoCargosServiceImpl) ConsumeMensajesKafka() {
	partitionConsumer, err := s.Consumer.ConsumePartition(s.TopicReply, 0, sarama.OffsetNewest)
	if err != nil {
		// Manejar el error, loggearlo, etc.
		return
	}
	defer partitionConsumer.Close()

	for {
		select {
		case msg := <-partitionConsumer.Messages():
			fmt.Println("Mensaje recibido de Kafka:", string(msg.Value))
			// Procesar el mensaje recibido (msg.Value)
			if msg != nil && msg.Value != nil {
				// Decodificar el mensaje JSON a una estructura NotificacionCargosVO
				var notificacion vo.NotificacionCargosVO
				if err := json.Unmarshal(msg.Value, &notificacion); err != nil {
					fmt.Println("Error al decodificar el mensaje JSON:", err)
					continue
				}

				fmt.Println("Mensaje a verificar:", notificacion.FirmaDigitalKarpay)

				// Verificar que todos los campos obligatorios estén presentes y válidos
				if s.validarCamposObligatorios(&notificacion) {
					// Verificar la firma Base64
					if s.verificarFirmaBase64(notificacion.FirmaDigitalKarpay) {
						fmt.Println("Firma y campos válidos, enviando mensaje al siguiente tópico...")

						// Llamar a la función para enviar el mensaje al siguiente tópico
						if err := s.enviarMensajeATopico(string(msg.Value), envs.Get("TOPICSEND", "topico")); err != nil {
							fmt.Println("Error al enviar mensaje al siguiente tópico:", err)
						}
					} else {
						fmt.Println("Firma Base64 inválida, el mensaje no se enviará")
					}
				} else {
					fmt.Println("Campos obligatorios faltantes o inválidos, el mensaje no se enviará")
				}
			}
		}
	}
}

// Función para verificar la firma Base64
func (s *ProcesamientoCargosServiceImpl) verificarFirmaBase64(firmaBase64 string) bool {
	// Decodificar la firma Base64
	_, err := base64.StdEncoding.DecodeString(firmaBase64)
	if err != nil {
		fmt.Println("Error al decodificar la firma Base64:", err)
		return false
	}

	// Si la decodificación tuvo éxito, asumimos que la firma es válida
	return true
}

// Función para producir mensajes en un tópico de Kafka
func (s *ProcesamientoCargosServiceImpl) produceMensajeKafka(notificaciones []vo.NotificacionCargosVO) error {
	for _, notificacion := range notificaciones {
		fmt.Println("Enviando mensaje a Kafka:", vo.NotificacionToString(notificacion))

		message := &sarama.ProducerMessage{
			Topic: s.TopicReply,
			Value: sarama.StringEncoder(vo.NotificacionToString(notificacion)), // Convierte la notificación a string
		}

		_, _, err := s.Producer.SendMessage(message)
		if err != nil {
			return err
		}
	}
	return nil
}

// Función para enviar un mensaje a otro tópico de Kafka
func (s *ProcesamientoCargosServiceImpl) enviarMensajeATopico(mensaje string, topic string) error {
	message := &sarama.ProducerMessage{
		Topic: topic,
		Value: sarama.StringEncoder(mensaje),
	}

	_, _, err := s.Producer.SendMessage(message)
	if err != nil {
		return err
	}
	return nil
}

// Función para validar los campos obligatorios
func (s *ProcesamientoCargosServiceImpl) validarCamposObligatorios(notificacion *vo.NotificacionCargosVO) bool {
	return notificacion.FolioOrden != 0 &&
		notificacion.FolioPaquete != 0 &&
		notificacion.FechaOperacion != "" &&
		notificacion.Monto != nil &&
		notificacion.IDTipoPago != 0 &&
		notificacion.ClaveRastreo != "" &&
		notificacion.FirmaDigitalKarpay != "" &&
		notificacion.IDEstado != 0
}
