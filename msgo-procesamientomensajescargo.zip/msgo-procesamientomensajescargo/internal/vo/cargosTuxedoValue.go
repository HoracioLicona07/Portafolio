package vo

type CargosTuxedoValue struct {
	MensajeTuxedoValue

	NumCargos     int
	Instituciones []interface{}
	InstClaves    []interface{}
	NumPaqPagos   []interface{}
	FoliosPagos   []interface{}
	MontoTotal    float64
	Saldo         float64
	SaldoRes      float64
	CerSerie      string
	AfectaSaldos  int16
	Particion     int16
}
