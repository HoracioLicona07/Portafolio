package vo

type MensajeTuxedoValue struct {
	NombreMensaje           string
	FechaMaquina            int
	HoraMaquina             int
	FechaOperacion          int
	FolioSolicitud          int
	FolioServidor           int
	EdoSolicitud            int16
	CveOwnInst              int
	CveInstitucion          int
	IndInstitucion          int16
	IndCertFirm             int16
	Modulo                  int16
	FolioSolicitudXCancelar int
	CerClave                string
	NumSerieCert            string
}
