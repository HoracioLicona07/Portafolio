package vo

import (
	"math/big"
)

type MensajesCargoVO struct {
	Fecha                   int
	Hora                    int
	FechaOperacion          int
	FolioServidor           int
	NumeroCargos            int
	IndicesBeneficiarios    []interface{} // Puedes reemplazar "interface{}" con el tipo adecuado si se conoce
	ClavesBeneficiarios     []interface{}
	FoliosInstruccionesPago []interface{}
	FoliosODPs              []interface{}
	MontoCargado            *big.Float // Usar big.Float para precisión decimal
	SaldoNOReservado        *big.Float
	SaldoReservado          *big.Float
}
