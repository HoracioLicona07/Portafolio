package vo

import (
	"fmt"
	"math/big"
)

type NotificacionCargosVO struct {
	FolioOrden         int
	FolioPaquete       int
	FechaOperacion     string
	Monto              *big.Float // Usar big.Float para precisión decimal
	IDTipoPago         int
	ClaveRastreo       string
	ClaveBeneficiario  *int // Usar puntero para manejar la posibilidad de nulo
	FirmaDigitalKarpay string
	IDEstado           int
}

// Función para convertir NotificacionCargosVO a string
func NotificacionToString(notificacion NotificacionCargosVO) string {
	return fmt.Sprintf(
		"FolioOrden: %d, FolioPaquete: %d, FechaOperacion: %s, Monto: %s, IDTipoPago: %d, ClaveRastreo: %s, ClaveBeneficiario: %v, FirmaDigitalKarpay: %s, IDEstado: %d",
		notificacion.FolioOrden, notificacion.FolioPaquete, notificacion.FechaOperacion,
		notificacion.Monto, notificacion.IDTipoPago, notificacion.ClaveRastreo,
		notificacion.ClaveBeneficiario, notificacion.FirmaDigitalKarpay, notificacion.IDEstado,
	)
}
