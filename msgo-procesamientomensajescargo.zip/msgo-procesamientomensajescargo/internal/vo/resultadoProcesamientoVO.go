package vo

type ResultadoProcesamientoVO struct {
	Mensaje string
	Codigo  *int // Usar puntero para manejar la posibilidad de nulo
}
