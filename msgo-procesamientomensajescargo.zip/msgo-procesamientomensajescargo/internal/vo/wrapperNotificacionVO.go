package vo

type WrapperNotificacionVO struct {
	Huella         string
	Mensaje        []byte
	BytesEnviados  int64
	BytesRecibidos int64
}
