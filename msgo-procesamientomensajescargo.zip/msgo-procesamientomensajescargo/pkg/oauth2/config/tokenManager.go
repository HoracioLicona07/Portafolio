package main

import (
	"encoding/base64"
	"encoding/json"
	"log"

	"192.168.1.46/gitlab/e-karpay-code/karpay_10/msgo-procesamientomensajescargo/-/tree/Develop/pkg/utils/httputil"
)

// Creamos un logger para registrar mensajes.
var Log = log.New(log.Writer(), "TokenManager", log.LstdFlags)

// Definimos la estructura TokenManager.
type TokenManager struct {
	ClientID     string
	ClientSecret string
	AccessURI    string
}

// Definimos el método getAccessToken de TokenManager.
func (tm *TokenManager) getAccessToken() string {
	// Concatenamos las credenciales del cliente en el formato "clienteId:clienteSecret".
	credentials := tm.ClientID + ":" + tm.ClientSecret
	// Codificamos las credenciales en base64.
	encodedCredentials := base64.StdEncoding.EncodeToString([]byte(credentials))

	// Definimos los encabezados HTTP.
	headers := map[string]string{
		"Accept":        "application/json",
		"Authorization": "Basic " + encodedCredentials,
	}

	// Enviamos una solicitud POST utilizando el método SendPostRequest del paquete httputil.
	response, err := httputil.SendPostRequest(tm.AccessURI, nil, headers)
	if err != nil {
		Log.Println(err)
		return ""
	}
	defer response.Body.Close()

	// Decodificamos la respuesta JSON recibida.
	var node map[string]interface{}
	err = json.NewDecoder(response.Body).Decode(&node)
	if err != nil {
		Log.Println(err)
		return ""
	}

	// Obtenemos el token de acceso de la respuesta JSON y lo retornamos en formato "Bearer token".
	accessToken := node["access_token"].(string)
	return "Bearer " + accessToken
}
