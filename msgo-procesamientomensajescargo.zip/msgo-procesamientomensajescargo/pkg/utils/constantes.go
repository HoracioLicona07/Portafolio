package utils

const (
	CLASSPATH = "classpath:messages"
	UTF_8     = "UTF-8"
	MESSAGE   = "message"
	DATA      = "data"
	STATUS    = "status"
	ROL_USE   = "ROLE_USER"
	// Endpoint y recursos
	ENDPOINT = "/praxis/v1.0/ekarpay/procesamiento/cargo"
	RESPONSE = "/response"
	HOME     = "/home"
	// Datos para obtener token
	AUTHORIZATION        = "Authorization"
	TYPEAUTHORIZATION    = "Basic "
	SEPARATORCREDENTIALS = ":"
	ACCESSTOKEN          = "access_token"
	BEARERTOKEN          = "Bearer "
	// Información de Swagger
	NOTIFICACIONESCONTROLLERGENERAL = "Recepción de notificaciones de cargo."
	HOMECONTROLLERGENERAL           = "Información básica del microservicio."
	BASEPACKAGE                     = "com.praxis.mx.controller"
	// Mensajes de validación desde message.properties con messageSource
	SERVICIO_DISPONIBLE = "service.enable"
	// Configuración de la base de datos
	HIKARIDATASOURCE = "spring.datasource.hikari"
	DATASOURCENAME   = "DSProcMsgCargo"
	// Expresiones regulares (Regex)
	DATEFORMAT    = "dd-MM-yyyy"
	DATEFORMATBMX = "yyyyMMdd"
	// Configuración de Kafka
	TOPIC         = "notificacionesCargos"
	GROUPID       = "respuestasProcesamiento"
	KAFKALISTENER = "kafkaListener"
	// Errores en la ejecución
	ERRORINDEXBOUNDEXCEPTION  = "error.index.bound.exception"
	ERRORCODEINVALIDSIGNATURE = 5463
	SUCCESSCODE               = 200
	ERROTGENERATEHUELLA       = "error.generate.huella"
	// Información de seguimiento en el registro (log)
	INVALIDSIGNATURE               = "error.invalid.signature"
	BYTESRECEIVED                  = "byes.received"
	ORDERTOPROCCES                 = "order.to.process"
	ORDERTOPROCCESNOTFOUND         = "order.to.process.not.found.in.db"
	MESSAGESENTTOKAFKA             = "message.sent.to.kafka"
	PROCESSEDMESSAGE               = "processed.message"
	KAFKAEXCEPTIONTOSEND           = "kafka.exception.to.send"
	MESSAGESENTWITHRESTTEMPLATE    = "message.sent.with.restTemplate"
	PROCESSEDMESSAGERETRIES        = "processed.message.retries"
	PROCESSEDMESSAGERETRIESEXCEDED = "processed.message.retries.execeded"
	MSGRECEIVEDPOST                = "msg.received.post"
	INVALIDSIGNATURECONFIRM        = "error.invalid.signature.confirm"
	ERRORDESFORMATERMESSAGE        = "error.desformater.message"
	// Valores generales
	DOUBLEQOUTES = ""
	FORMATOMONTO = "%1$09d"
	CONFIRMATION = "Confirmacion "
	// Estados de la orden
	LIQUIDADA8     = 8
	ENVIANDOCORE13 = 13
	// Tipos de mensajes
	CARGO = "Cargo"
	// Usuario universal
	IDUSUARIOUNIVERSAL = 0
)
