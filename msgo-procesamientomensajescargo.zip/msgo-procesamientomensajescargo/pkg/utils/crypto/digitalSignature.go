package crypto

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"io"
)

// DigitalSignature realiza operaciones de firma digital y verificación.
type DigitalSignature struct{}

var (
	defaultHashAlgorithm   = "SHA-256"
	defaultCipherAlgorithm = "AES/CBC/PKCS5PADDING"
	defaultKeySize         = 16 // Tamaño de la clave en bytes
	defaultIVSize          = 16 // Tamaño del IV en bytes
)

// newAESKey crea una nueva clave AES.
func newAESKey(key []byte) (cipher.Block, error) {
	return aes.NewCipher(key)
}

// generateRandomIV genera un vector de inicialización aleatorio.
func generateRandomIV(size int) ([]byte, error) {
	iv := make([]byte, size)
	_, err := io.ReadFull(rand.Reader, iv)
	if err != nil {
		return nil, err
	}
	return iv, nil
}

// encryptAES encripta los datos utilizando AES.
func encryptAES(key, iv, data []byte) ([]byte, error) {
	block, err := newAESKey(key)
	if err != nil {
		return nil, err
	}

	cipherText := make([]byte, len(data))
	cipher.NewCBCEncrypter(block, iv).CryptBlocks(cipherText, data)

	return cipherText, nil
}

// decryptAES desencripta los datos utilizando AES.
func decryptAES(key, iv, cipherText []byte) ([]byte, error) {
	block, err := newAESKey(key)
	if err != nil {
		return nil, err
	}

	plainText := make([]byte, len(cipherText))
	cipher.NewCBCDecrypter(block, iv).CryptBlocks(plainText, cipherText)

	return plainText, nil
}

// sign realiza la firma digital de los datos utilizando AES y SHA-256.
func (ds *DigitalSignature) sign(data []byte, key []byte) ([]byte, error) {
	digest := sha256.Sum256(data)
	encryptedDigest, err := encryptAES(key, key[:defaultKeySize], digest[:])
	if err != nil {
		return nil, err
	}
	return encryptedDigest, nil
}

// signString firma un mensaje utilizando AES y SHA-256.
func (ds *DigitalSignature) signString(message string, key []byte) (string, error) {
	data := []byte(message)
	encryptedDigest, err := ds.sign(data, key)
	if err != nil {
		return "", err
	}
	return base64.StdEncoding.EncodeToString(encryptedDigest), nil
}

// verify verifica la firma digital de los datos utilizando AES y SHA-256.
func (ds *DigitalSignature) verify(data []byte, encryptedDigest []byte, key []byte) bool {
	decryptedDigest, err := decryptAES(key, key[:defaultKeySize], encryptedDigest)
	if err != nil {
		return false
	}

	digest := sha256.Sum256(data)
	return hmac.Equal(digest[:], decryptedDigest)
}

// verifyString verifica la firma digital de un mensaje utilizando AES y SHA-256.
func (ds *DigitalSignature) verifyString(message string, encryptedDigest string, key []byte) bool {
	data := []byte(message)
	decodedDigest, err := base64.StdEncoding.DecodeString(encryptedDigest)
	if err != nil {
		return false
	}
	return ds.verify(data, decodedDigest, key)
}
