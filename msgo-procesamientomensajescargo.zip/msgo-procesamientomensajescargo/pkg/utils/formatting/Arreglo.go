package formatting

type Arreglo struct {
	XmlFormatterConfig // Extiende de XmlFormatterConfig

	TamanoArreglo string
	Mapeo         string
	Campos        []Campo
}
