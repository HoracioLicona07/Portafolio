package formatting

type ArregloCompuesto struct {
	XmlFormatterConfig // Extiende de XmlFormatterConfig

	TamanoArreglo string
	Mapeo         string
	Subtipo       string
	Campos        []Campo
}
