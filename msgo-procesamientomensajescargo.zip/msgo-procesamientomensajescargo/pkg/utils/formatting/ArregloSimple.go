package formatting

type ArregloSimple struct {
	XmlFormatterConfig // Extiende de XmlFormatterConfig

	Subtipo       string
	TamanoArreglo string
	Mapeo         string
	Tamano        int
	Requerido     int
}
