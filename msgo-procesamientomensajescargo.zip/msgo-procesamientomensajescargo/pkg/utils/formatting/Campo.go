package formatting

type Campo struct {
	XmlFormatterConfig // Extiende de XmlFormatterConfig

	Tamano     string
	Requerido  int
	FormatoRed string
	Mapeo      string
}
