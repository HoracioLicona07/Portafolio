package formatting

import "fmt"

const (
	MEDIUM_PRIORITY         = 7
	HIGH_PRIORITY           = 9
	NORMAL_PRIORITY         = 4
	CARGOS_PRIORITY         = 5
	JNDI_RECEIVE_QUEUE      = "receiveQueue"
	JNDI_RESPONSE_QUEUE     = "responseQueue"
	JNDI_REQUEST_QUEUE      = "requestQueue"
	JNDI_REQUEST_QUEUE_ARA  = "requestQueueARA"
	JNDI_ERROR_QUEUE        = "errorQueue"
	JNDI_COMM_QUEUE         = "commQueue"
	JNDI_ERROR_COMM_QUEUE   = "errorCommQueue"
	JNDI_INCOM_QUEUE        = "incomQueue"
	JNDI_CONNECTION_FACTORY = "MyConnectionFactory"
	JNDI_JMSCOM_PREFIX      = "java:/"
	APLICACION              = "spei"
	// SPEI                        = "spei"
	SPID                        = "spid"
	SICE                        = "sice"
	SICE_USD                    = "siceusd"
	ARCHIVO_PROPERTIES          = "speilight.properties"
	MSG_NOTIF                   = "MSG_NOTIF_TUX"
	JNDI_DS_OMISION             = "banxico.spei.jdbc.BanxicoSpei"
	NUM_MAX_ORD                 = 30000
	NUM_MAX_BLOQUE_SEC          = 1000
	NUM_ALEAT_LENGHT            = 30
	LISTENER_COMMLISTENER       = "COMMLISTENER"
	DEMONIO_TIPO_NOTIFICACION   = "NotificacionDemonio"
	SPEI_CERO_BYTES_BACKUP_FILE = "SPEICero_"
)

type Config string

const (
	PARTITION_SIZE                            Config = "partitionsize"
	SI_CLAVE                                  Config = "si_clave"
	ARA_CERT_ID                               Config = "aracertid"
	BANXICO_CERT_ID                           Config = "banxicocertid"
	SERVICE_SPEI                              Config = "servicespei"
	SERVICE_ARA                               Config = "serviceara"
	IP_BANXICO                                Config = "ipsbanxico"
	IP_BANXICO_ARA                            Config = "ipsbanxicoara"
	RANGO_INICIAL_PTOS                        Config = "ranginiptos"
	NUM_INTENTOS_CONEXION                     Config = "numintenconex"
	TIME_TO_WAIT_ARA                          Config = "timeara"
	TIME_TO_WAIT_FOR_CERTIFICATE              Config = "timetowaitforcertificate"
	TIME_TO_WAIT_SPEI                         Config = "timespei"
	FECHA_OPERACION                           Config = "fechaoperacion"
	LONG_MAX_SERIE_CERT                       Config = "longmaxseriecert"
	CDE_LENGTH                                Config = "longcde"
	NOMBRE_SRV_ARA                            Config = "servicioara"
	NOMBRE_SRV_SPEI                           Config = "serviciospei"
	TAM_MAX_TRAMA                             Config = "tammaxtrama"
	PATH_XML_FORMATTING                       Config = "pathxml"
	PATH_CERTIFICATES                         Config = "pathcert"
	TIME_TO_RECONNECT_SPEI_DEAD_SRVR          Config = "timeToReconnectSPEIDeadSrvr"
	TIME_TO_RECONNECT_SPEI_LOGIN_FAIL         Config = "timeToReconnectSPEILoginFail"
	TIME_TO_RECONNECT_SPEI_NO_SERVICE         Config = "timeToReconnectSPEINoService"
	TIME_TO_RECONNECT_SPEI_SOCKET_DISCONECTED Config = "timeToReconnectSPEISocketDisconected"
	ATTEMPT_TO_SEND_NOT_PROCESING_MSG         Config = "attemptToSendNotProcesingMsg"
	ATTEMPT_TO_CONNECT_ARA                    Config = "attemptToConnectARA"
	ATTEMPT_TO_RECONNECT                      Config = "attemptToReConnect"
	DETAILED_DEBUG_SPEI_PROC                  Config = "detailedDebugSPEI"
	IPSERVERSPEILIGHT                         Config = "ipserverspeilight"
	PORTSERVERSPEILIGHT                       Config = "portserverspeilight"
	READ_SIZE_FRAME                           Config = "readSizeFrame"
	ATTEMPT_DEQUEING_MSG_ARA                  Config = "attemptDequeingMsgARA"
	ATTEMPT_DEQUEING_MSG_SPEI                 Config = "attemptDequeingMsgSPEI"
	PROTOCOLSERVERSPEILIGHT                   Config = "protocolserverspeilight"
	SIMULATEARACOMMERROR                      Config = "simulateARACommError"
	RECEIVEDBYTESDIR                          Config = "receivedBytesDir"
	NUM_INTENTOS_ENVIO                        Config = "numIntentosEnvio"
	NUM_INTENTOS_FALLA                        Config = "numIntentosFalla"
	OPERACION_CONTINUA                        Config = "operacionContinua"
	REMOTE_INITIAL_CONTEXT                    Config = "remoteInitialContextFactory"
	SECURITY_PROVIDER                         Config = "securityProvider"
	VERIFY_SIGN_ALGORITHMS                    Config = "verifySignAlgorithms"
	SIGN_ALGORITHMS                           Config = "signAlgorithms"
	PRIVATE_KEY_ALGORITHM                     Config = "privateKeyAlgorithm"
	CDE_ENCRYPT_ALGORITHM                     Config = "cdeEncryptAlgorithm"
	CDE_DIGEST_ALGORITHM                      Config = "cdeDigestAlgorithm"
	ARA_ID_DECRYPT_ALGORITHM                  Config = "araIdDecryptAlgorithm"
	CONNECTION_TIMEOUT                        Config = "connectionTimeout"
	MODO_FALLOS_SUMABYTES                     Config = "modoFallosSumabytes"
	MODO_CIFRADO                              Config = "modoCifrado"
	MOSTRAR_BYTES_ENTRADA                     Config = "mostrarBytesEntrada"
)

type SignatureAlg string

const (
	SHA256WITHRSA              SignatureAlg = "SHA256withRSA"
	MD5WITHRSA                 SignatureAlg = "MD5withRSA"
	SHA1WITHRSA                SignatureAlg = "SHA1withRSA"
	SHA1WITHDSA                SignatureAlg = "SHA1withDSA"
	MD2WITHRSAENCRYPTION       SignatureAlg = "MD2WITHRSAENCRYPTION"
	MD2WITHRSA                 SignatureAlg = "MD2WITHRSA"
	MD5WITHRSAENCRYPTION       SignatureAlg = "MD5WITHRSAENCRYPTION"
	SHA1WITHRSAENCRYPTION      SignatureAlg = "SHA1WITHRSAENCRYPTION"
	SHA224WITHRSAENCRYPTION    SignatureAlg = "SHA224WITHRSAENCRYPTION"
	SHA224WITHRSA              SignatureAlg = "SHA224WITHRSA"
	SHA256WITHRSAENCRYPTION    SignatureAlg = "SHA256WITHRSAENCRYPTION"
	SHA384WITHRSAENCRYPTION    SignatureAlg = "SHA384WITHRSAENCRYPTION"
	SHA384WITHRSA              SignatureAlg = "SHA384WITHRSA"
	SHA512WITHRSAENCRYPTION    SignatureAlg = "SHA512WITHRSAENCRYPTION"
	SHA512WITHRSA              SignatureAlg = "SHA512WITHRSA"
	SHA1WITHRSAANDMGF1         SignatureAlg = "SHA1WITHRSAANDMGF1"
	SHA224WITHRSAANDMGF1       SignatureAlg = "SHA224WITHRSAANDMGF1"
	SHA256WITHRSAANDMGF1       SignatureAlg = "SHA256WITHRSAANDMGF1"
	SHA384WITHRSAANDMGF1       SignatureAlg = "SHA384WITHRSAANDMGF1"
	SHA512WITHRSAANDMGF1       SignatureAlg = "SHA512WITHRSAANDMGF1"
	RIPEMD160WITHRSAENCRYPTION SignatureAlg = "RIPEMD160WITHRSAENCRYPTION"
	RIPEMD160WITHRSA           SignatureAlg = "RIPEMD160WITHRSA"
	RIPEMD128WITHRSAENCRYPTION SignatureAlg = "RIPEMD128WITHRSAENCRYPTION"
	RIPEMD128WITHRSA           SignatureAlg = "RIPEMD128WITHRSA"
	RIPEMD256WITHRSAENCRYPTION SignatureAlg = "RIPEMD256WITHRSAENCRYPTION"
	RIPEMD256WITHRSA           SignatureAlg = "RIPEMD256WITHRSA"
)

type Queues int

const (
	REQUEST_QUEUE     Queues = 1
	RESPONSE_QUEUE    Queues = 2
	RECEIVE_QUEUE     Queues = 3
	ERROR_QUEUE       Queues = 4
	COMM_QUEUE        Queues = 5
	ERROR_COMM_QUEUE  Queues = 6
	INCOMING_QUEUE    Queues = 7
	REQUEST_QUEUE_ARA Queues = 8
)

type BanxicoService byte

const (
	FEC  BanxicoService = 1
	SPEI BanxicoService = 2
	ARA  BanxicoService = 3
	CEP  BanxicoService = 4
)

func GetOrdinalServiceNumber(val byte) int {
	switch val {
	case byte(FEC):
		return int(FEC)
	case byte(SPEI):
		return int(SPEI)
	case byte(ARA):
		return int(ARA)
	case byte(CEP):
		return int(CEP)
	default:
		return 0
	}
}

type SPEIMessage int

const (
	ENSESION                  SPEIMessage = 13
	CARGOS                    SPEIMessage = 24
	ABONOS                    SPEIMessage = 25
	PAQCOBROS                 SPEIMessage = 26
	ACUSERECIBO               SPEIMessage = 27
	AVISOTRASPASOSIACSPEI     SPEIMessage = 30
	MSJCATALOGOS              SPEIMessage = 31
	FINREENVIO                SPEIMessage = 32
	ELIMINARPAQ               SPEIMessage = 33
	ACUSECANCELACION          SPEIMessage = 34
	AVISOMANTOCRT             SPEIMessage = 35
	ACUSEMANTOCRT             SPEIMessage = 36
	AVISOMANTOINST            SPEIMessage = 39
	ACUSECAMBIARESERVADO      SPEIMessage = 40
	ACUSETRASPASOSPEISIAC     SPEIMessage = 42
	ACUSECANCTRASPASOSPEISIAC SPEIMessage = 44
	MSJNOPROCESABLE           SPEIMessage = 45
	ACUSEPARTESAC             SPEIMessage = 46
	AVISOCAMBIACONEC          SPEIMessage = 47
	LIQUIDATRASPASOSPEISIAC   SPEIMessage = 48
	ELIMINARTRASPASO          SPEIMessage = 50
	LIQUIDACIONFINAL          SPEIMessage = 51
	CLVSIM                    SPEIMessage = 80
)

func (sm SPEIMessage) String() string {
	switch sm {
	case ABONOS:
		return "ABONOS"
	case ACUSECAMBIARESERVADO:
		return "ACUSECAMBIARESERVADO"
	case ACUSECANCELACION:
		return "ACUSECANCELACION"
	case ACUSECANCTRASPASOSPEISIAC:
		return "ACUSECANCTRASPASOSPEISIAC"
	case ACUSEMANTOCRT:
		return "ACUSEMANTOCRT"
	case ACUSERECIBO:
		return "ACUSERECIBO"
	case ACUSETRASPASOSPEISIAC:
		return "ACUSETRASPASOSPEISIAC"
	case AVISOCAMBIACONEC:
		return "AVISOCAMBIACONEC"
	case AVISOMANTOCRT:
		return "AVISOMANTOCRT"
	case AVISOMANTOINST:
		return "AVISOMANTOINST"
	case AVISOTRASPASOSIACSPEI:
		return "AVISOTRASPASOSIACSPEI"
	case CARGOS:
		return "CARGOS"
	case ELIMINARPAQ:
		return "ELIMINARPAQ"
	case ELIMINARTRASPASO:
		return "ELIMINARTRASPASO"
	case ENSESION:
		return "ENSESION"
	case FINREENVIO:
		return "FINREENVIO"
	case LIQUIDACIONFINAL:
		return "LIQUIDACIONFINAL"
	case LIQUIDATRASPASOSPEISIAC:
		return "LIQUIDATRASPASOSPEISIAC"
	case MSJCATALOGOS:
		return "MSJCATALOGOS"
	case MSJNOPROCESABLE:
		return "MSJNOPROCESABLE"
	case PAQCOBROS:
		return "PAQCOBROS"
	case CLVSIM:
		return "CLVSIM"
	default:
		return "Unknown SPEIMessage"
	}
}

type CEPMessage int

const (
	ENSESIONCEP        CEPMessage = 13
	ACUSERECIBOCEP     CEPMessage = 27
	MSJNOPROCESABLECEP CEPMessage = 45
	FINOPERACION       CEPMessage = 52
	PAQCDA             CEPMessage = 197
	ACUSECAS           CEPMessage = 198
	UNKNOWN            CEPMessage = -1
)

type FECMessage int

const (
	LOGOUT        FECMessage = 0
	INICIATALK    FECMessage = 16
	CONFPASSWD    FECMessage = 236
	DEADSRVR      FECMessage = 243
	SMTTYCLOSE    FECMessage = 244
	GREETING      FECMessage = 247
	CHPSWDFAIL    FECMessage = 249
	AREYOUALIVE   FECMessage = 245
	LOGINREQ      FECMessage = 254
	PSSWDREQ      FECMessage = 255
	LOGGED        FECMessage = 253
	LOGINFAIL     FECMessage = 251
	NOSERVICE     FECMessage = 252
	LOGIN         FECMessage = 1
	PASSWD        FECMessage = 2
	IAMALIVE      FECMessage = 7
	CONEXION      FECMessage = 16
	CHANGEPASS    FECMessage = 212
	ACUSEPARTECAS FECMessage = 198
	SMBITACORA    FECMessage = 213
)

func (fm FECMessage) String() string {
	switch fm {
	case LOGGED:
		return "LOGGED"
	case SMBITACORA:
		return "SMBITACORA"
	case LOGINFAIL:
		return "LOGINFAIL"
	case AREYOUALIVE:
		return "AREYOUALIVE"
	case CHPSWDFAIL:
		return "CHPSWDFAIL"
	case CONFPASSWD:
		return "CONFPASSWD"
	case DEADSRVR:
		return "DEADSRVR"
	case IAMALIVE:
		return "IAMALIVE"
	case LOGINREQ:
		return "LOGINREQ"
	case NOSERVICE:
		return "NOSERVICE"
	case PSSWDREQ:
		return "PSSWDREQ"
	default:
		return "Unknown FECMessage"
	}
}

type ARAMessage int

const (
	LOGOUTARA      ARAMessage = 0
	LOGGEDARA      ARAMessage = 253
	CONNUSR        ARAMessage = 16
	PIDECRTNVOFMT  ARAMessage = 80
	IDFMAALEAT     ARAMessage = 76
	IDUSUARIOALEAT ARAMessage = 183
	CRTENALERTA    ARAMessage = 193
	CRTNOEXISTE    ARAMessage = 194
	REGCRTNVOFMT   ARAMessage = 195
	AUTNOCONN      ARAMessage = 197
	OPRNOPERMIT    ARAMessage = 203
	TIPODESC       ARAMessage = 50
)

func (am ARAMessage) String() string {
	switch am {
	case LOGOUTARA:
		return "LOGOUTARA"
	case LOGGEDARA:
		return "LOGGEDARA"
	case CONNUSR:
		return "CONNUSR"
	case PIDECRTNVOFMT:
		return "PIDECRTNVOFMT"
	case IDFMAALEAT:
		return "IDFMAALEAT"
	case IDUSUARIOALEAT:
		return "IDUSUARIOALEAT"
	case CRTENALERTA:
		return "CRTENALERTA"
	case CRTNOEXISTE:
		return "CRTNOEXISTE"
	case REGCRTNVOFMT:
		return "REGCRTNVOFMT"
	case AUTNOCONN:
		return "AUTNOCONN"
	case OPRNOPERMIT:
		return "OPRNOPERMIT"
	case TIPODESC:
		return "TIPODESC"
	default:
		return "Unknown ARAMessage"
	}
}

type BusinessMessage int

const (
	ORDENTOPOT              BusinessMessage = 210
	MANTOCRT                BusinessMessage = 208
	REENVIO                 BusinessMessage = 207
	ORDENTOPOV              BusinessMessage = 206
	CANCELAPAGO             BusinessMessage = 205
	CAMBIARESERVADO         BusinessMessage = 202
	TRASPASOSPEISIAC        BusinessMessage = 199
	CANCELATRASPASOSPEISIAC BusinessMessage = 197
	INISESIONCIFRADA        BusinessMessage = 220
	RESPCLVSIM              BusinessMessage = 221
)

func (bm BusinessMessage) String() string {
	switch bm {
	case CAMBIARESERVADO:
		return "CAMBIARESERVADO"
	case CANCELAPAGO:
		return "CANCELAPAGO"
	case CANCELATRASPASOSPEISIAC:
		return "CANCELATRASPASOSPEISIAC"
	case MANTOCRT:
		return "MANTOCRT"
	case ORDENTOPOT:
		return "ORDENTOPOT"
	case ORDENTOPOV:
		return "ORDENTOPOV"
	case REENVIO:
		return "REENVIO"
	case TRASPASOSPEISIAC:
		return "TRASPASOSPEISIAC"
	default:
		return "Unknown BusinessMessage"
	}
}

type BusinessMessageCEP int

type SystemMessage int

const (
	INTENCION_PAGO SystemMessage = 1001
	RECIBE_PAGO    SystemMessage = 1002
	ALERTA_TUXEDO  SystemMessage = 1003
	MSJEDOCNX      SystemMessage = 1004
	CDE            SystemMessage = 1005
)

func (sm SystemMessage) String() string {
	switch sm {
	case INTENCION_PAGO:
		return "INTENCION_PAGO"
	case RECIBE_PAGO:
		return "RECIBE_PAGO"
	case CDE:
		return "CDE"
	default:
		return "Unknown SystemMessage"
	}
}

type TestMessage int

const (
	TEST_ALL_TYPES TestMessage = 555
)

func (tm TestMessage) String() string {
	switch tm {
	case TEST_ALL_TYPES:
		return "TEST_ALL_TYPES"
	default:
		return "Unknown TestMessage"
	}
}

type ConnectionState int

const (
	CONNECTING         ConnectionState = 1
	AVAILABLE          ConnectionState = 2
	NOTAVAILABLE       ConnectionState = 3
	DISCONNECTED       ConnectionState = 4
	DEAD_SERVER        ConnectionState = 5
	NO_SERVICE         ConnectionState = 6
	LOGIN_FAIL         ConnectionState = 7
	SOCKET_DISCONECTED ConnectionState = 8
)

type SendingState int

const (
	UNAVAILABLE SendingState = 1
	FREE        SendingState = 2
	WAIT        SendingState = 3
	CONTINUE    SendingState = 4
)

type TypesMessages int

const (
	SEND TypesMessages = iota
	RECEPTION
	DUMMY_SEND
	DUMMY_RECEPTION
)

type MessageState int

const (
	SENDED MessageState = iota
	RECEIVED
	CONFIRMED
)

type CertificateMaintenanceStatus int

const (
	ALTA_CERTIFICADO       CertificateMaintenanceStatus = 'A'
	BAJA_CERTIFICADO       CertificateMaintenanceStatus = 'T'
	ALTA_CERTIFICADO_NIVEL CertificateMaintenanceStatus = 'N'
	BAJA_CERTIFICADO_NIVEL CertificateMaintenanceStatus = 'B'
)

type CertificateState int

const (
	PROCESSING CertificateState = 'X'
	ACTIVE     CertificateState = 'A'
	REVOKED    CertificateState = 'R'
	REMOVED    CertificateState = 'B'
	EXPIRED    CertificateState = 'V'
)

type MainControllerState int

type Errors int

const (
	UNKNOWN_OPERATION Errors = iota
	UNKNOWN_ERROR_CODE
	MISSING_LOGIN_INFO
	SERVICE_NOT_SPECIFIED
	PARSER_ERROR
	SOCKET_EROR
	PROPERTIES
	FILE_NOT_FOUND
	ERROR_IN_FILE
	OBJECT_NULL
	DONT_HAVE_PROVILEGES
	ELEMENT_NOT_FOUND
	NO_DATA
	CANT_SAVE
	NETWORK_TIMEOUT
	READING_PROPERTY
	INVALID_SIGNATURE
	SENDING_NOT_PROCESSING_MESSAGE
	IILEGAL_ARGUMENT
	MISSING_CERTIFICATE_KEYWORD
	INVALID_CERTIFICATE_KEYWORD
	RETURN_A_DUMMY_MESSAGE
	IMPOSSIBLE_LOCATE_SERVICE
	CONSECUTIVE_NUMBER_ERROR
	CDE_EXT_ERROR
)

// OrderStatus defines the order status constants
type OrderStatus int

const (
	ERROR_EN_FOLIO OrderStatus = iota
)

var orderStatusDescriptions = map[OrderStatus]string{
	ERROR_EN_FOLIO: "Error en folio",
}

func (os OrderStatus) getStatusDescription() string {
	if desc, found := orderStatusDescriptions[os]; found {
		return desc
	}
	return "Unknown OrderStatus"
}

// EnlaceCodes defines the enlace codes constants
type EnlaceCodes int

const (
	ERROR_FIRMA EnlaceCodes = iota + 8
	ERROR_EDO_PAQUETE
	ERROR_CVE_FIRMA
	ERROR_CVE_PRIV
	ERROR_CERT_PUBLICO
	ERROR_CERT_PRIVADO
	ERROR_CVE_PUB
	ERROR_FIRMA_GENERADA
)

var enlaceCodesDescriptions = map[EnlaceCodes]string{
	ERROR_FIRMA:          "Error en la firma",
	ERROR_EDO_PAQUETE:    "Error en el estado del paquete",
	ERROR_CVE_FIRMA:      "Error en la firma",
	ERROR_CVE_PRIV:       "Error certificado privado corrupto",
	ERROR_CERT_PUBLICO:   "",
	ERROR_CERT_PRIVADO:   "",
	ERROR_CVE_PUB:        "",
	ERROR_FIRMA_GENERADA: "",
}

func (ec EnlaceCodes) getErrorDescription() string {
	if desc, found := enlaceCodesDescriptions[ec]; found {
		return desc
	}
	return "Unknown EnlaceCodes"
}

// MsjNoProcesableCode defines the MsjNoProcesableCode constants
type MsjNoProcesableCode int

const (
	ERROR_INDICE_ORDENANTE MsjNoProcesableCode = iota + 3
	ERROR_INDICADOR_TIPO
	ERROR_MSJ_INVALIDO
	ERROR_SYNC_POS_MAYOR
	ERROR_SYNC_POS_MSJ
	ERROR_SYNC_ENVIO_MSJ_INESPERADO
	ERROR_RESYNC_INCONGRUENCIA
	ERROR_RESYNC_INESPERADA
	ERROR_RESYNC_INESPERADA_DOS
	ERROR_MSJ_PROTOCOLO_NO_DEFINIDO
	ERROR_CERT_INDICE
	ERROR_CERT_PETICION
	ERROR_CERT_ALTA
	ERROR_CERT_ALTA_NIVEL
	ERROR_CALC_BYTES
	ERROR_CAS_NO_ESPERADO
	ERROR_SOCKET_TAM_MEN
	ERROR_OPE_RECHAZADA_ESPERA_LIQFIN
	ERROR_OPE_FUERA_HORARIO
	ERROR_OPE_FECHA_DIFERENTE
	ERROR_NO_CONOCIDO
	ERROR_TOPOLOGIA_NO_ACEPTADA
)

var msjNoProcesableCodeDescriptions = map[MsjNoProcesableCode]string{
	ERROR_INDICE_ORDENANTE:            "Falla en el indice de la instituciordenante (o el mensaje generdesconexi",
	ERROR_INDICADOR_TIPO:              "Valor incorrecto en indicador o tipo",
	ERROR_MSJ_INVALIDO:                "Tipo de mensaje invalido",
	ERROR_SYNC_POS_MAYOR:              "Al estar en Proceso de sincronizaciel Cliente solicita desde una posicimayor a  la enviada",
	ERROR_SYNC_POS_MSJ:                "Al estar en Proceso de sincronizaciel Cliente solicita desde una posicique no corresponde al inicio de un mensaje",
	ERROR_SYNC_ENVIO_MSJ_INESPERADO:   "Si el cliente no ha terminado el proceso de sincronizaciy envun mensaje diferente al esperado.",
	ERROR_RESYNC_INCONGRUENCIA:        "Al estar en proceso de resincronizaciel servidor detecta una incongruenacia al enviar un mensaje.",
	ERROR_RESYNC_INESPERADA:           "Si el cliente solicita Reenvio y el servidor no detecta que este en proceso de resincronizaci",
	ERROR_RESYNC_INESPERADA_DOS:       "Si el cliente solicita Reenvio y el servidor no detecta que este en proceso de resincronizaci",
	ERROR_MSJ_PROTOCOLO_NO_DEFINIDO:   "Cuando el servidor recibe un tipo de mensaje cuyo tipo no corresponde a ninguno de los presentados en el protocolo",
	ERROR_CERT_INDICE:                 "Error en para borrar nivel de certificado.",
	ERROR_CERT_PETICION:               "Error al pedir certificado al ARA",
	ERROR_CERT_ALTA:                   "Error al dar de alta certificado",
	ERROR_CERT_ALTA_NIVEL:             "Error al dar de alta nivel para certificado",
	ERROR_CALC_BYTES:                  "Error al calcular bytes para formato, por indicador y tipo incorrecto",
	ERROR_CAS_NO_ESPERADO:             "Error no esperaba mensaje parteCAS",
	ERROR_SOCKET_TAM_MEN:              "Tamadel mensaje es mayor al maximo permitido.",
	ERROR_OPE_RECHAZADA_ESPERA_LIQFIN: "Ya no se puede realizar ninguna operacion..... En espera de Liquidacion Final",
	ERROR_OPE_FUERA_HORARIO:           "Tipo de Pago Fuera de Horario",
	ERROR_OPE_FECHA_DIFERENTE:         "Solicitud con fecha de operacidiferente",
	ERROR_NO_CONOCIDO:                 "Mensaje NoProcesable Error Desconocido",
	ERROR_TOPOLOGIA_NO_ACEPTADA:       "Error, Topologia no aceptada",
}

func (mpc MsjNoProcesableCode) getErrorDescription() string {
	if desc, found := msjNoProcesableCodeDescriptions[mpc]; found {
		return desc
	}
	return "Unknown MsjNoProcesableCode"
}

// Notification defines the notification constants
type Notification int

const (
	NOTIF_TUX Notification = iota
	NOTIF_ARA
	NOTIF_BM
)

var notificationDescriptions = map[Notification]string{
	NOTIF_TUX: "Notificacion generada por Tuxedo",
	NOTIF_ARA: "Notificacion generada por ARA",
	NOTIF_BM:  "Notificiacion generada por servidor de Banco de Mexico",
}

func (n Notification) getDescription() string {
	if desc, found := notificationDescriptions[n]; found {
		return desc
	}
	return "Unknown Notification"
}

// TuxedoNotification defines the Tuxedo notification constants
type TuxedoNotification int

const (
	ERR_TUX_QUEUE_PEN TuxedoNotification = iota + 131
	ERR_TUX_DES_OPER
	ERR_TUX_RECONEX
	ERR_DATOS_SESION_GET
	ERR_DATOS_SESION_SET
	ERR_CREAR_SOCKET
	ERR_ENCOLAR_MSG
	ERR_TUX_MSJNOPROC
	ERR_RECONEX_STOP
	ERR_PASSW_FAILD
	LIQ_FINAL
	LIQ_FINALT
	LIQ_FINALV
	ERR_GENERAL
	ERR_DEQUEUING_MSG_SPEI
	ERR_TUX_PROC_CERTIFICATES
	FIN_REPROCESS_MESSAGES
	FIN_SYNCRONIZATION_PROCESS
	ERR_DOC_EMPTY
	ERR_SESION_CIFRADA
)

var tuxedoNotificationDescriptions = map[TuxedoNotification]string{
	ERR_TUX_QUEUE_PEN:          "ERROR. No se pudieron eliminar mensaje de PENDIENTES",
	ERR_TUX_DES_OPER:           "ERROR. No se pudieron deshacer operaciones en TUX.",
	ERR_TUX_RECONEX:            "ERROR. Al detener la reconexion del sistema",
	ERR_DATOS_SESION_GET:       "ERROR. No se pudieron obtener Datos de Sesion",
	ERR_DATOS_SESION_SET:       "ERROR. No se pudieron establecer Datos de Sesion",
	ERR_CREAR_SOCKET:           "ERROR. Error al crear el socket de conexion...",
	ERR_ENCOLAR_MSG:            "ERROR. Error al encolar mensaje",
	ERR_TUX_MSJNOPROC:          "Mensaje no procesable",
	ERR_RECONEX_STOP:           "ERROR. El numero de intentos de Reconexion llego a su limite ....  Se detendra la REECONEXION ",
	ERR_PASSW_FAILD:            "ERROR. El password de FEC es incorrecto. Verifique valores en Base de Datos ....  Se detendra la REECONEXION ",
	LIQ_FINAL:                  "Se recibio la LIQUIDACION-FINAL.  Se detendran OPERACIONES ",
	LIQ_FINALT:                 "Se recibio la LIQUIDACION-FINAL a encolar en incom con prioridad normal.  Se detendran OPERACIONES ",
	LIQ_FINALV:                 "Se recibio la LIQUIDACION-FINAL a encolar en incom con prioridad alta.  Se detendran OPERACIONES ",
	ERR_GENERAL:                "ERROR desconocido a nivel de comunicacion",
	ERR_DEQUEUING_MSG_SPEI:     "ERROR. Los intentos para desencolar el mensaje SPEI llegaron al limite. El msg se encolara en la Queue ERROR_COMM_QUEUE",
	ERR_TUX_PROC_CERTIFICATES:  "ERROR. No se han podido Procesar correctamente los certificados.",
	FIN_REPROCESS_MESSAGES:     "ERROR. No se han podido Procesar correctamente los certificados.",
	FIN_SYNCRONIZATION_PROCESS: "ERROR. No se han podido Procesar correctamente los certificados.",
	ERR_DOC_EMPTY:              "ERROR. El archivo comunicacion.properties esta vacio.",
	ERR_SESION_CIFRADA:         "ERROR. No se puede iniciar operaciones en modo CIFRADO, se realizara la desconexion",
}

func (tn TuxedoNotification) getNotificationDescription() string {
	if desc, found := tuxedoNotificationDescriptions[tn]; found {
		return desc
	}
	return "Unknown TuxedoNotification"
}

// BMNotification defines the BM notification constants
type BMNotification int

const (
	ERR_FIRMA_BM_SPEI BMNotification = iota + 126
)

var bmNotificationDescriptions = map[BMNotification]string{
	ERR_FIRMA_BM_SPEI: "ERROR. Al validar la firma del servidor SPEI, esta fue invalida",
}

func (bn BMNotification) getNotificationDescription() string {
	if desc, found := bmNotificationDescriptions[bn]; found {
		return desc
	}
	return "Unknown BMNotification"
}

// ARANotification defines the ARA notification constants
type ARANotification int

const (
	ERR_CNX_ARA ARANotification = iota + 121
	ERR_FIRMA_ARA
	ERR_CRT_ARA
	ERR_CNX_ARA_1
	ERR_CNX_ARA_0
	ERR_DEQUEUING_MSG_ARA
)

var araNotificationDescriptions = map[ARANotification]string{
	ERR_CNX_ARA:           "ERROR. Error al intentar la conexion con servidor ARA",
	ERR_FIRMA_ARA:         "ERROR. Al validar la firma del servidor ARA, esta fue invalida",
	ERR_CRT_ARA:           "ERROR. No se cuenta con el certificado del ARA",
	ERR_CNX_ARA_1:         "ERROR. Los intentos de conexion al servidor ARA llegaron al limite...",
	ERR_CNX_ARA_0:         "ERROR. Surgio un error en la conexion con servidor ARA. Procediendo a siguiente intento",
	ERR_DEQUEUING_MSG_ARA: "ERROR. Los intentos para desencolar el mensaje del ARA llegaron al limite. El msg se encolara en la Queue ERROR_COMM_QUEUE",
}

func (an ARANotification) getNotificationDescription() string {
	if desc, found := araNotificationDescriptions[an]; found {
		return desc
	}
	return "Unknown ARANotification"
}

// ARALoginResult defines the ARA login result constants
type ARALoginResult int

const (
	EXITO_LOGIN_ARA ARALoginResult = iota
	ERROR_LOGIN_ARA_FUERADESERVICIO
	ERROR_LOGIN_ARA_INVALID_CERT_PASSW
	ERROR_LOGIN_ARA_NOTUXCONEXION
)

func (lr ARALoginResult) getCode() int {
	return int(lr)
}

// ClaveSimetrica defines the symmetric key constants
type ClaveSimetrica int

const (
	ClaveSimetricaID ClaveSimetrica = iota + 1
)

var claveSimetricaDescriptions = map[ClaveSimetrica]struct {
	algoritmo       string
	modo            string
	keyLength       int
	datosAuxLengths []int
	maxPaddingSize  int
}{
	ClaveSimetricaID: {
		algoritmo:       "AES",
		modo:            "AES/CBC/PKCS5PADDING",
		keyLength:       16,
		datosAuxLengths: []int{16},
		maxPaddingSize:  16,
	},
}

func (cs ClaveSimetrica) getID() int {
	return int(cs)
}

func (cs ClaveSimetrica) getAlgorithm() string {
	if desc, found := claveSimetricaDescriptions[cs]; found {
		return desc.algoritmo
	}
	return "Unknown ClaveSimetrica"
}

func (cs ClaveSimetrica) getModo() string {
	if desc, found := claveSimetricaDescriptions[cs]; found {
		return desc.modo
	}
	return "Unknown ClaveSimetrica"
}

func (cs ClaveSimetrica) getKeyLength() int {
	if desc, found := claveSimetricaDescriptions[cs]; found {
		return desc.keyLength
	}
	return 0
}

func (cs ClaveSimetrica) getDatosAuxLengths() []int {
	if desc, found := claveSimetricaDescriptions[cs]; found {
		return desc.datosAuxLengths
	}
	return nil
}

func (cs ClaveSimetrica) getMaxPaddingSize() int {
	if desc, found := claveSimetricaDescriptions[cs]; found {
		return desc.maxPaddingSize
	}
	return 0
}

// Example usage:
func main() {
	bmNotification := ERR_FIRMA_BM_SPEI
	fmt.Println(bmNotification.getNotificationDescription())

	araNotification := ERR_CNX_ARA
	fmt.Println(araNotification.getNotificationDescription())

	araLoginResult := EXITO_LOGIN_ARA
	fmt.Println(araLoginResult.getCode())

	claveSimetrica := ClaveSimetricaID
	fmt.Println(claveSimetrica.getID())
	fmt.Println(claveSimetrica.getAlgorithm())
	fmt.Println(claveSimetrica.getModo())
	fmt.Println(claveSimetrica.getKeyLength())
	fmt.Println(claveSimetrica.getDatosAuxLengths())
	fmt.Println(claveSimetrica.getMaxPaddingSize())
}
