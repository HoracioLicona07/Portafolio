package formatting

type Mensaje struct {
	ID                string
	Nombre            string
	Recibido          int
	Firmado           int
	Acuse             int
	Partido           int
	SumaBytes         int
	Cifrado           int
	Bean              string
	Campos            []Campo
	Mensajes          []Mensaje
	ArreglosSimples   []ArregloSimple
	Arreglos          []Arreglo
	ArreglosCompuesto []ArregloCompuesto
}
