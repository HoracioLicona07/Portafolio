package formatting

// ParserMensaje es una interfaz que define los métodos para analizar XML y obtener un Mensaje y una slice de objetos de orden.
type ParserMensaje interface {
	ParseXML()
	GetMensaje() Mensaje
	GetOrderObjOfMensaje() []interface{}
}
