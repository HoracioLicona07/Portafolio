package formatting

import (
	"io"
	"strconv"

	"github.com/beevik/etree"
)

type ParserMensajeDom struct {
	document          *etree.Document
	mensaje           *Mensaje
	orderObjOfMensaje []interface{}
}

func NewParserMensajeDom(in io.Reader) (*ParserMensajeDom, error) {
	pmd := &ParserMensajeDom{
		orderObjOfMensaje: make([]interface{}, 0),
	}
	if err := pmd.InputStream2Document(in); err != nil {
		return nil, err
	}
	return pmd, nil
}

func (pmd *ParserMensajeDom) InputStream2Document(in io.Reader) error {
	doc := etree.NewDocument()
	_, err := doc.ReadFrom(in)
	if err != nil {
		return err
	}
	pmd.document = doc
	return nil
}

func (pmd *ParserMensajeDom) ParseXMLRoot() {
	root := pmd.document.Root()
	pmd.ParseXML(root)
}

func (pmd *ParserMensajeDom) ParseXML(node *etree.Element) {
	if node.Tag == "MsgConfiguration" {
		for _, child := range node.ChildElements() {
			if child.Tag == "Mensaje" {
				pmd.ParseMensaje(child)
			}
		}
	}
}

func (pmd *ParserMensajeDom) ParseMensaje(node *etree.Element) {
	mensaje := &Mensaje{}
	pmd.ParseAttsMensaje(mensaje, node)
	pmd.mensaje = mensaje

	for _, child := range node.ChildElements() {
		switch child.Tag {
		case "Mensaje":
			m := &Mensaje{}
			pmd.ParseMensaje(child) // Llamada recursiva para parsear el mensaje hijo
			pmd.mensaje.Mensajes = append(pmd.mensaje.Mensajes, *m)
		case "Campo":
			campo := pmd.ParseAttsCampo(child)
			pmd.mensaje.Campos = append(pmd.mensaje.Campos, *campo)
		case "ArregloSimple":
			as := pmd.ParseAttsArregloSimple(child)
			pmd.mensaje.ArreglosSimples = append(pmd.mensaje.ArreglosSimples, *as)
		case "ArregloCompuesto":
			ac := pmd.ParseAttsArregloCompuesto(child)
			pmd.ParseContentArregloCompuesto(child, ac)
			pmd.mensaje.ArreglosCompuesto = append(pmd.mensaje.ArreglosCompuesto, *ac)
		}
	}
}

func (pmd *ParserMensajeDom) ParseContentArregloCompuesto(node *etree.Element, ac *ArregloCompuesto) {
	for _, child := range node.ChildElements() {
		if child.Tag == "Campo" {
			campo := pmd.ParseAttsCampo(child)
			ac.Campos = append(ac.Campos, *campo)
		}
	}
}

func (pmd *ParserMensajeDom) ParseAttsMensaje(m *Mensaje, node *etree.Element) {
	m.ID = node.SelectAttrValue("id", "")
	m.Nombre = node.SelectAttrValue("nombre", "")
	m.Bean = node.SelectAttrValue("bean", "")
	m.Acuse, _ = strconv.Atoi(node.SelectAttrValue("acuse", "0"))
	m.Firmado, _ = strconv.Atoi(node.SelectAttrValue("firmado", "0"))
	m.Partido, _ = strconv.Atoi(node.SelectAttrValue("partido", "0"))
	m.Recibido, _ = strconv.Atoi(node.SelectAttrValue("recibido", "0"))
	m.SumaBytes, _ = strconv.Atoi(node.SelectAttrValue("sumaBytes", "0"))
	m.Cifrado, _ = strconv.Atoi(node.SelectAttrValue("cifrado", "0"))
}

func (pmd *ParserMensajeDom) ParseAttsCampo(node *etree.Element) *Campo {
	campo := &Campo{}
	campo.ID = node.SelectAttrValue("id", "")
	campo.Mapeo = node.SelectAttrValue("mapeo", "")
	campo.Orden, _ = strconv.Atoi(node.SelectAttrValue("orden", "0"))
	campo.TipoDato = node.SelectAttrValue("tipoDato", "")
	campo.Tamano = node.SelectAttrValue("tamano", "")
	campo.Requerido, _ = strconv.Atoi(node.SelectAttrValue("requerido", "0"))
	campo.FormatoRed = node.SelectAttrValue("formato", "")
	pmd.orderObjOfMensaje = append(pmd.orderObjOfMensaje, campo)
	return campo
}

func (pmd *ParserMensajeDom) ParseAttsArregloSimple(node *etree.Element) *ArregloSimple {
	as := &ArregloSimple{}
	as.ID = node.SelectAttrValue("id", "")
	as.Orden, _ = strconv.Atoi(node.SelectAttrValue("orden", "0"))
	as.TipoDato = node.SelectAttrValue("tipoDato", "")
	as.Subtipo = node.SelectAttrValue("subtipo", "")
	as.TamanoArreglo = node.SelectAttrValue("tamanoArreglo", "")
	as.Mapeo = node.SelectAttrValue("mapeo", "")
	as.Tamano, _ = strconv.Atoi(node.SelectAttrValue("tamano", "0"))
	as.Requerido, _ = strconv.Atoi(node.SelectAttrValue("requerido", "0"))
	pmd.orderObjOfMensaje = append(pmd.orderObjOfMensaje, as)
	return as
}

func (pmd *ParserMensajeDom) ParseAttsArregloCompuesto(node *etree.Element) *ArregloCompuesto {
	ac := &ArregloCompuesto{}
	ac.ID = node.SelectAttrValue("id", "")
	ac.Orden, _ = strconv.Atoi(node.SelectAttrValue("orden", "0"))
	ac.TipoDato = node.SelectAttrValue("tipoDato", "")
	ac.TamanoArreglo = node.SelectAttrValue("tamanoArreglo", "")
	ac.Mapeo = node.SelectAttrValue("mapeo", "")
	ac.Subtipo = node.SelectAttrValue("subtipo", "")
	pmd.orderObjOfMensaje = append(pmd.orderObjOfMensaje, ac)
	return ac
}

func (pmd *ParserMensajeDom) GetMensaje() *Mensaje {
	return pmd.mensaje
}

func (pmd *ParserMensajeDom) GetOrderObjOfMensaje() []interface{} {
	return pmd.orderObjOfMensaje
}
