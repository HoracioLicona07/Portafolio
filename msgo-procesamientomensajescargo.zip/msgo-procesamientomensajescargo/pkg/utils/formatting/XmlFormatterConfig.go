package formatting

type XmlFormatterConfig struct {
	ID       string
	Orden    int
	TipoDato string
}
