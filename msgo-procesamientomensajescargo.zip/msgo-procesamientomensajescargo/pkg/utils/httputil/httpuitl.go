package httputil

import (
	"bytes"
	"encoding/json"
	"net/http"
)

// SendPostRequest envía una solicitud POST a la URI especificada con el payload y cabeceras dadas.
func SendPostRequest(uri string, payload interface{}, headers map[string]string) (*http.Response, error) {
	// Codificar el payload a JSON
	payloadBytes, err := json.Marshal(payload)
	if err != nil {
		return nil, err
	}

	req, err := http.NewRequest(http.MethodPost, uri, bytes.NewBuffer(payloadBytes))
	if err != nil {
		return nil, err
	}

	// Establecer el Content-Type y otras cabeceras necesarias
	req.Header.Set("Content-Type", "application/json")
	for key, value := range headers {
		req.Header.Set(key, value)
	}

	client := http.Client{}
	return client.Do(req)
}
