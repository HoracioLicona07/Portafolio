package exceptions

// FormatException es una estructura que representa una excepción de formato.
type FormatException struct {
	message string
}

// NewFormatException crea una nueva instancia de FormatException con el mensaje especificado.
func NewFormatException(message string) *FormatException {
	return &FormatException{message: message}
}

// Error devuelve el mensaje de error de la excepción.
func (fe *FormatException) Error() string {
	return fe.message
}
