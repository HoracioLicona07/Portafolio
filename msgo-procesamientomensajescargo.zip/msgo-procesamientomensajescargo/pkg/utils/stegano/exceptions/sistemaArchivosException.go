package exceptions

// SistemaArchivosException es una estructura que representa una excepción relacionada con el sistema de archivos.
type SistemaArchivosException struct {
	message string
}

// NewSistemaArchivosException crea una nueva instancia de SistemaArchivosException con el mensaje especificado.
func NewSistemaArchivosException(message string) *SistemaArchivosException {
	return &SistemaArchivosException{message: message}
}

// Error devuelve el mensaje de error de la excepción.
func (sae *SistemaArchivosException) Error() string {
	return sae.message
}
