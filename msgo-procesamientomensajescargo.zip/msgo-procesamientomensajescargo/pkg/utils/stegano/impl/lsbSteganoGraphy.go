package impl

import (
	"errors"
	"image"
	"image/color"
	"image/jpeg"
	"image/png"
	"os"
	"path/filepath"
	"strings"
)

// FORMATS define los formatos de imagen aceptados.
var FORMATS = []string{"png", "jpeg", "jpg", "gif"}

// LSBSteganography implementa la técnica de esteganografía utilizando el método de bits menos significativos (LSB).
type LSBSteganography struct {
	miVariable    []byte
	miVariableTam int
}

// NewLSBSteganography crea una nueva instancia de LSBSteganography con la miVariable y miVariableTam especificadas.
func NewLSBSteganography(miVariable []byte, miVariableTam int) *LSBSteganography {
	return &LSBSteganography{
		miVariable:    miVariable,
		miVariableTam: miVariableTam,
	}
}

// isValidImageFormat verifica si el formato del archivo de imagen es válido.
func (lsb *LSBSteganography) isValidImageFormat(rutaArchivo string) bool {
	for _, formato := range FORMATS {
		if strings.HasSuffix(strings.ToLower(rutaArchivo), "."+formato) {
			return true
		}
	}
	return false
}

// OpenImg abre y valida un archivo de imagen con el formato especificado.
func (lsb *LSBSteganography) OpenImg(rutaArchivo string) (image.Image, error) {
	if !lsb.isValidImageFormat(rutaArchivo) {
		return nil, errors.New("formato de imagen inválido")
	}

	archivo, err := os.Open(rutaArchivo)
	if err != nil {
		return nil, err
	}
	defer archivo.Close()

	img, _, err := image.Decode(archivo)
	if err != nil {
		return nil, err
	}

	return img, nil
}

// SaveImg guarda una imagen en la ruta de archivo especificada.
func (lsb *LSBSteganography) SaveImg(img image.Image, rutaArchivo string) error {
	archivo, err := os.Create(rutaArchivo)
	if err != nil {
		return err
	}
	defer archivo.Close()

	extension := filepath.Ext(rutaArchivo)
	if extension == ".jpg" || extension == ".jpeg" {
		return jpeg.Encode(archivo, img, nil)
	} else if extension == ".png" {
		return png.Encode(archivo, img)
	}

	return errors.New("formato de imagen no admitido")
}

// HideInImage oculta un mensaje dentro de una imagen utilizando la técnica LSB.
func (lsb *LSBSteganography) HideInImage(img image.Image) (image.Image, error) {
	offset := 200
	space := 2

	if lsb.miVariable == nil || len(lsb.miVariable) == 0 {
		return nil, errors.New("miVariable no válida")
	}

	if space < 0 || offset < 0 {
		return nil, errors.New("parámetros no válidos")
	}

	bounds := img.Bounds()
	x, y := 0, 0
	cont := 0

	for i := 0; i < offset; i++ {
		x++
		if x >= bounds.Max.X {
			y++
			x = 0
		}
	}

	newImg := image.NewRGBA(bounds)

	for _, b := range lsb.miVariable {
		for k := 7; k >= 0; k-- {
			if x >= bounds.Max.X {
				y++
				x = 0
			}
			if y >= bounds.Max.Y {
				break
			}
			c := img.At(x, y)
			r, g, blue, _ := c.RGBA()

			bitVal := uint32(b>>uint(k)) & 0x1
			blue = (blue & 0xF2) | bitVal
			newColor := color.RGBA{uint8(r >> 8), uint8(g >> 8), uint8(blue), 0xFF}
			newImg.Set(x, y, newColor)

			x = x + space + 1
			cont++
		}
	}

	return newImg, nil
}

// RevealText revela el texto oculto de una imagen.
func (lsb *LSBSteganography) RevealText(img image.Image) ([]byte, error) {
	offset := 200
	space := 2

	if lsb.miVariableTam <= 0 {
		return nil, errors.New("miVariableTam no válida")
	}

	if space < 0 || offset < 0 {
		return nil, errors.New("parámetros no válidos")
	}

	bounds := img.Bounds()
	x, y := 0, 0
	cont := 0

	for i := 0; i < offset; i++ {
		x++
		if x >= bounds.Max.X {
			y++
			x = 0
		}
	}

	var bytes []byte

	for j := 0; j < lsb.miVariableTam; j++ {
		var byteVal byte
		for k := 7; k >= 0; k-- {
			if x >= bounds.Max.X {
				y++
				x = 0
			}
			if y >= bounds.Max.Y {
				break
			}
			c := img.At(x, y)
			_, _, blue, _ := c.RGBA()
			byteVal = (byteVal << 1) | byte(blue&0x1)
			x = x + space + 1
			cont++
		}
		bytes = append(bytes, byteVal)
	}

	return bytes, nil
}
