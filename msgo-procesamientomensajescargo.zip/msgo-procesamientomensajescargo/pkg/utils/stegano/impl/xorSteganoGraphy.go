package impl

import (
	"errors"
	"io"
	"os"
)

const DEFAULT_BUFFER_SIZE = 8192

// XorSteganography implementa la técnica de esteganografía utilizando el método de operación XOR.
type XorSteganography struct{}

// Hide oculta un mensaje dentro del archivo utilizando la operación XOR.
func (x *XorSteganography) Hide(carrier, carrierDestino *os.File, key []byte, mensaje []byte) (*os.File, error) {
	if carrier == nil {
		return nil, errors.New("carrier no puede ser nil")
	}
	info, err := carrier.Stat()
	if err != nil {
		return nil, err
	}
	if info.Size() == 0 {
		return nil, errors.New("carrier no puede estar vacío")
	}

	if carrierDestino == nil {
		return nil, errors.New("carrierDestino no puede ser nil")
	}

	if _, err := carrierDestino.Seek(0, io.SeekStart); err != nil {
		return nil, err
	}

	keyXor := key[0]

	buffer := make([]byte, DEFAULT_BUFFER_SIZE)
	for {
		read, err := carrier.Read(buffer)
		if err != nil {
			if err == io.EOF {
				break
			}
			return nil, err
		}
		for i := 0; i < read; i++ {
			buffer[i] = buffer[i] ^ keyXor
		}
		_, err = carrierDestino.Write(buffer[:read])
		if err != nil {
			return nil, err
		}
	}

	return carrierDestino, nil
}

// Show revela el mensaje oculto en el archivo utilizando la operación XOR.
func (x *XorSteganography) Show(carrier *os.File, key []byte) ([]byte, error) {
	if carrier == nil {
		return nil, errors.New("carrier no puede ser nil")
	}
	info, err := carrier.Stat()
	if err != nil {
		return nil, err
	}
	if info.Size() == 0 {
		return nil, errors.New("carrier no puede estar vacío")
	}

	keyXor := key[0]

	buffer := make([]byte, DEFAULT_BUFFER_SIZE)
	var result []byte
	for {
		read, err := carrier.Read(buffer)
		if err != nil {
			if err == io.EOF {
				break
			}
			return nil, err
		}
		for i := 0; i < read; i++ {
			result = append(result, buffer[i]^keyXor)
		}
	}

	return result, nil
}

// ProcessHidden procesa el pipelining para ocultar información.
func (x *XorSteganography) ProcessHidden(input *os.File) (*os.File, error) {
	archivoSalida, err := os.Create(input.Name() + "_xor_pipe")
	if err != nil {
		return nil, err
	}
	defer archivoSalida.Close()

	_, err = x.Hide(input, archivoSalida, []byte{255}, nil)
	if err != nil {
		return nil, err
	}

	return archivoSalida, nil
}

// ProcessShow procesa el pipelining para mostrar información.
func (x *XorSteganography) ProcessShow(input []byte) ([]byte, error) {
	tempFile, err := createTempFile(input)
	if err != nil {
		return nil, err
	}
	defer os.Remove(tempFile.Name())
	defer tempFile.Close()

	result, err := x.Show(tempFile, []byte{255})
	if err != nil {
		return nil, err
	}

	destino := make([]byte, len(result))
	copy(destino, result)

	return destino, nil
}

func createTempFile(data []byte) (*os.File, error) {
	tempFile, err := os.CreateTemp("", "temp_xor_*.dat")
	if err != nil {
		return nil, err
	}
	defer tempFile.Close()

	_, err = tempFile.Write(data)
	if err != nil {
		return nil, err
	}

	_, err = tempFile.Seek(0, io.SeekStart)
	if err != nil {
		return nil, err
	}

	return tempFile, nil
}
