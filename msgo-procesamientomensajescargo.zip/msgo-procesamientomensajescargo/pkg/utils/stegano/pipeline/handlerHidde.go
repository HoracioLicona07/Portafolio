package pipeline

// HandlerHidde es una interfaz que define un método para procesar datos ocultos.
type HandlerHidde interface {
	// ProcessHidden procesa los datos ocultos de entrada y devuelve el resultado.
	ProcessHidden(input interface{}) interface{}
}
