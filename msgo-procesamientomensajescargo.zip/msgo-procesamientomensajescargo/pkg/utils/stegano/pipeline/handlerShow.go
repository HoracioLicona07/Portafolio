package pipeline

// HandlerShow es una interfaz que define un método para procesar datos ocultos.
type HandlerShow interface {
	// ProcessShow procesa los datos ocultos de entrada y devuelve el resultado.
	ProcessShow(input interface{}) interface{}
}
