package pipeline

// PipelineHidden implementa un pipeline de manejo de datos ocultos.
type PipelineHidden struct {
	currentHandler HandlerHidde
}

// NewPipelineHidden crea una nueva instancia de PipelineHidden con el manejador inicial.
func NewPipelineHidden(currentHandler HandlerHidde) *PipelineHidden {
	return &PipelineHidden{currentHandler: currentHandler}
}

// AddHandler agrega un nuevo manejador al pipeline y devuelve un nuevo PipelineHidden.
func (p *PipelineHidden) AddHandler(newHandler HandlerHidde) *PipelineHidden {
	return &PipelineHidden{
		currentHandler: HandlerHiddeFunc(func(input interface{}) interface{} {
			return newHandler.ProcessHidden(p.currentHandler.ProcessHidden(input))
		}),
	}
}

// Execute ejecuta el pipeline con el valor de entrada dado.
func (p *PipelineHidden) Execute(input interface{}) interface{} {
	return p.currentHandler.ProcessHidden(input)
}

// HandlerHiddeFunc es un tipo de función que implementa la interfaz HandlerHidde.
type HandlerHiddeFunc func(input interface{}) interface{}

// ProcessHidden implementa el método ProcessHidden de la interfaz HandlerHidde.
func (f HandlerHiddeFunc) ProcessHidden(input interface{}) interface{} {
	return f(input)
}
