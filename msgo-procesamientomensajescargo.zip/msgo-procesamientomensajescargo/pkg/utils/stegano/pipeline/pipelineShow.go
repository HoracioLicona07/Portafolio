package pipeline

// PipelineShow implementa un pipeline de manejo de datos para mostrar.
type PipelineShow struct {
	currentHandler HandlerShow
}

// NewPipelineShow crea una nueva instancia de PipelineShow con el manejador inicial.
func NewPipelineShow(currentHandler HandlerShow) *PipelineShow {
	return &PipelineShow{currentHandler: currentHandler}
}

// AddHandler agrega un nuevo manejador al pipeline y devuelve un nuevo PipelineShow.
func (p *PipelineShow) AddHandler(newHandler HandlerShow) *PipelineShow {
	return &PipelineShow{
		currentHandler: HandlerShowFunc(func(input interface{}) interface{} {
			return newHandler.ProcessShow(p.currentHandler.ProcessShow(input))
		}),
	}
}

// Execute ejecuta el pipeline con el valor de entrada dado.
func (p *PipelineShow) Execute(input interface{}) interface{} {
	return p.currentHandler.ProcessShow(input)
}

// HandlerShowFunc es un tipo de función que implementa la interfaz HandlerShow.
type HandlerShowFunc func(input interface{}) interface{}

// ProcessShow implementa el método ProcessShow de la interfaz HandlerShow.
func (f HandlerShowFunc) ProcessShow(input interface{}) interface{} {
	return f(input)
}
