package stegano

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/base64"
	"log"
	"os"
	"strconv"
)

const (
	FILE_NAME_1 = 1
	FILE_NAME_2 = 2
	FILE_NAME_3 = 3
	FILE_NAME_4 = 4
	FILE_NAME_5 = 5

	FILE_SIZE_XOR_OUTPUT_1 = 1391
	FILE_SIZE_XOR_OUTPUT_2 = 2061
	FILE_SIZE_XOR_OUTPUT_3 = 1517
	FILE_SIZE_XOR_OUTPUT_4 = 1301
	FILE_SIZE_XOR_OUTPUT_5 = 1729

	KEY_FILE_TAM_1 = 55
	KEY_FILE_TAM_2 = 110
	KEY_FILE_TAM_3 = 64
	KEY_FILE_TAM_4 = 32
	KEY_FILE_TAM_5 = 64

	PATH       = "src/test/resources"
	KEY_FILE_1 = PATH + "/libs/jackson-datatype-jsr310-2.13.3.jar"
	KEY_FILE_2 = PATH + "/libs/jakarta.xml.bind-api-2.3.3.jar"
	KEY_FILE_3 = PATH + "/libs/kotlin-compiler-embeddable-1.5.31.jar"
	KEY_FILE_4 = PATH + "/libs/zstd-jni-1.5.0-4.jar"
	KEY_FILE_5 = PATH + "/libs/kafka_2.13-3.1.1-test.jar"
)

func main() {
	args := os.Args[1:]
	if len(args) < 1 {
		log.Fatal("Operación no especificada")
	}

	operacion := args[0]

	switch operacion {
	case "set":
		if len(args) < 6 {
			log.Fatal("Argumentos insuficientes para la operación 'set'")
		}
		imagen := args[1]
		jar := args[2]
		jarFinal := args[3]
		key := []byte(args[4])

		tamXor, err := SetKey(jar, imagen, jarFinal, key)
		if err != nil {
			log.Fatalf("Error fijando la key: %v", err)
		}
		log.Printf("Key almacenada en: %s %d %d", jarFinal, len(key), tamXor)

	case "get":
		if len(args) < 4 {
			log.Fatal("Argumentos insuficientes para la operación 'get'")
		}
		jar := args[1]
		tamKey := parseInt(args[2])
		tamXor := parseInt(args[3])

		key, err := GetKey(jar, tamKey, int64(tamXor))
		if err != nil {
			log.Fatalf("Error obteniendo la key: %v", err)
		}
		log.Printf("Credencial: %s", string(key))

	case "firma":
		if len(args) < 2 {
			log.Fatal("Argumentos insuficientes para la operación 'firma'")
		}
		mensaje := args[1]
		firma, err := Sign(mensaje)
		if err != nil {
			log.Fatalf("Firma es válida? false")
		}
		log.Printf("Firma: %s", firma)

	case "Check":
		if len(args) < 3 {
			log.Fatal("Argumentos insuficientes para la operación 'Check'")
		}
		mensaje := args[1]
		firma := args[2]
		valida, err := IsValid(mensaje, firma)
		if err != nil {
			log.Fatalf("Firma es válida? false")
		}
		if valida {
			log.Printf("Firma es válida? %v", valida)
		}

	default:
		log.Fatalf("Operación no válida: %s", operacion)
	}
}

func GetDailyKey(llaveMaestra []byte, fecha string, algoritmo string, provider string) ([]byte, error) {
	key := []byte(llaveMaestra)
	salt := key[:16]
	mac := hmac.New(sha256.New, salt)
	_, err := mac.Write([]byte(fecha))
	if err != nil {
		return nil, err
	}
	llaveDiaria := mac.Sum(nil)
	return llaveDiaria, nil
}

func GetKeys() ([]byte, []byte, error) {
	// Implementación de GetKeys...
	return nil, nil, nil
}

func GetKeyFromFileNumber(keyNumber int) ([]byte, error) {
	// Implementación de GetKeyFromFileNumber...
	return nil, nil
}

func GetKey(fileJar string, tamKey int, fileSizeXorFile int64) ([]byte, error) {
	// Implementación de GetKey...
	return nil, nil
}

func SetKey(fileJar string, fileImgPng string, salidaJar string, key []byte) (int64, error) {
	// Implementación de SetKey...
	return 0, nil
}

func Sign(message string) (string, error) {
	key := []byte("supersecrethmackey")
	mac := hmac.New(sha256.New, key)
	_, err := mac.Write([]byte(message))
	if err != nil {
		return "", err
	}
	signature := mac.Sum(nil)
	return base64.StdEncoding.EncodeToString(signature), nil
}

func IsValid(message string, signature string) (bool, error) {
	decodedSignature, err := base64.StdEncoding.DecodeString(signature)
	if err != nil {
		return false, err
	}
	key := []byte("supersecrethmackey")
	mac := hmac.New(sha256.New, key)
	_, err = mac.Write([]byte(message))
	if err != nil {
		return false, err
	}
	expectedSignature := mac.Sum(nil)
	return hmac.Equal(decodedSignature, expectedSignature), nil
}

func parseInt(s string) int {
	val, err := strconv.Atoi(s)
	if err != nil {
		log.Fatalf("Error al convertir a entero: %v", err)
	}
	return val
}
