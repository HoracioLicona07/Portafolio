package utils

// Singleton es una estructura que implementa el patrón Singleton.
type Singleton struct {
	Size int64
}

var instance *Singleton

// GetInstance devuelve la instancia única del Singleton.
func GetInstance() *Singleton {
	return instance
}

// NewSingleton crea una nueva instancia del Singleton si aún no existe.
func NewSingleton() *Singleton {
	if instance == nil {
		instance = &Singleton{}
	}
	return instance
}
