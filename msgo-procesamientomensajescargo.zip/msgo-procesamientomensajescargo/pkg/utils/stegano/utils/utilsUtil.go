package utils

import (
	"bytes"
	"encoding/binary"
)

type UtilsUtil struct {
}

func (u *UtilsUtil) BytesToLong(bytes []byte) int64 {
	buffer := u.bytesToBuffer(bytes)
	var value int64
	binary.Read(buffer, binary.BigEndian, &value)
	return value
}

func (u *UtilsUtil) BytesToChar(bytes []byte) rune {
	buffer := u.bytesToBuffer(bytes)
	var value rune
	binary.Read(buffer, binary.BigEndian, &value)
	return value
}

func (u *UtilsUtil) LongToBytes(x int64) []byte {
	buffer := new(bytes.Buffer)
	binary.Write(buffer, binary.BigEndian, x)
	return buffer.Bytes()
}

func (u *UtilsUtil) CharToBytes(x rune) []byte {
	buffer := new(bytes.Buffer)
	binary.Write(buffer, binary.BigEndian, x)
	return buffer.Bytes()
}

func (u *UtilsUtil) bytesToBuffer(data []byte) *bytes.Reader {
	buffer := bytes.NewReader(data)
	return buffer
}
