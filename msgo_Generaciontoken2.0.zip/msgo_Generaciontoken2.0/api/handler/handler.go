package handler

import (
	"net/http"

	"192.168.1.46/gitlab/e-karpay-code/karpay_10/msgo-generaciontoken/-/tree/Develop/internal/config"
	"192.168.1.46/gitlab/e-karpay-code/karpay_10/msgo-generaciontoken/-/tree/Develop/internal/healthcheck"
	"192.168.1.46/gitlab/e-karpay-code/karpay_10/msgo-generaciontoken/-/tree/Develop/internal/middleware"
	"192.168.1.46/gitlab/e-karpay-code/karpay_10/msgo-generaciontoken/-/tree/Develop/pkg/token"

	"github.com/gin-gonic/gin"
)

// SetupRoutes define las rutas y los handlers para el servicio.
func SetupRoutes(cfg *config.Config) *gin.Engine {
	router := gin.Default()

	// Endpoint de Health Check
	router.GET("/healthcheck", healthcheck.HealthCheck)

	// Grupo de rutas que requieren autenticación
	api := router.Group("/api")
	api.Use(middleware.AuthMiddleware(cfg))
	{
		api.GET("/validate", func(c *gin.Context) {
			// Este endpoint solo responde si el token es válido.
			// La validación se realiza en el middleware.
			c.JSON(200, gin.H{"status": "token is valid"})
		})
	}

	// Endpoint para autenticar y obtener un token.
	router.POST("/authenticate", func(c *gin.Context) {
		var creds token.Credentials
		if err := c.ShouldBindJSON(&creds); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "Failed to parse request"})
			return
		}

		jwtToken, err := token.Authenticate(&creds)
		if err != nil {
			c.JSON(http.StatusUnauthorized, gin.H{"error": "Invalid credentials"})
			return
		}

		c.JSON(http.StatusOK, gin.H{"token": jwtToken})
	})

	return router
}
