package main

import (
	"fmt"
	"log"

	"192.168.1.46/gitlab/e-karpay-code/karpay_10/msgo-generaciontoken/-/tree/Develop/api/handler"
	"192.168.1.46/gitlab/e-karpay-code/karpay_10/msgo-generaciontoken/-/tree/Develop/internal/config"
	"192.168.1.46/gitlab/e-karpay-code/karpay_10/msgo-generaciontoken/-/tree/Develop/internal/database"

	"github.com/joho/godotenv"
)

func init() {
	// Carga las variables de entorno desde .env
	if err := godotenv.Load(); err != nil {
		log.Println("No .env file found")
	}
}

func main() {
	database, err := database.ConectarSQLServer()
	if err != nil {
		fmt.Println("Error al conectar a SQL Server:", err)
		return
	}

	// Cierra la conexión cuando ya no se necesite
	defer database.Close()
	// Cargar configuraciones
	cfg := config.Load()

	// Iniciar servidor Gin y configurar rutas
	router := handler.SetupRoutes(cfg)

	// Iniciar servidor en el puerto configurado
	addr := fmt.Sprintf(":%s", cfg.Port)
	log.Printf("Starting server on %s", addr)
	if err := router.Run(addr); err != nil {
		log.Fatalf("Failed to start server: %v", err)
	}
}
