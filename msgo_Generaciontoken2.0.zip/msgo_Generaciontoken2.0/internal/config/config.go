package config

import (
	"os"
)

type Config struct {
	Port string
}

// Load cargará la configuración desde las variables de entorno.
func Load() *Config {
	port := getEnv("PORT", "8081")

	return &Config{
		Port: port,
	}
}

func getEnv(key, defaultValue string) string {
	value := os.Getenv(key)
	if value == "" {
		return defaultValue
	}
	return value
}
