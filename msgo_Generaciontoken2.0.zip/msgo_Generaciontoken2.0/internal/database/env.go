package database

import (
	"log"
	"os"

	"github.com/joho/godotenv"
)

func init() {
	err := godotenv.Load()
	if err != nil {
		log.Fatal("Error al cargar el archivo .env")
	}
}

func Get(key, def string) string {
	value, ok := os.LookupEnv(key) //devuelve una variable boolean
	if ok {
		return value
	}
	//log
	log.Println(key, ":valor default")
	return def
}
