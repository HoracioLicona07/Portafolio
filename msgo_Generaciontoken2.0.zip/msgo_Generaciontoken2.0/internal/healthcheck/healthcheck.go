package healthcheck

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

// HealthCheck es un endpoint para verificar la salud del servicio.
func HealthCheck(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{"status": "UP"})
}
