package middleware

import (
	"net/http"
	"strings"

	"192.168.1.46/gitlab/e-karpay-code/karpay_10/msgo-generaciontoken/-/tree/Develop/internal/config"
	"192.168.1.46/gitlab/e-karpay-code/karpay_10/msgo-generaciontoken/-/tree/Develop/pkg/token"

	"github.com/gin-gonic/gin"
)

// AuthMiddleware es un middleware que valida los tokens JWT.
func AuthMiddleware(cfg *config.Config) gin.HandlerFunc {
	return func(c *gin.Context) {
		// Obtener el token del header 'Authorization'.
		authHeader := c.GetHeader("Authorization")
		if authHeader == "" {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "Authorization header not found"})
			return
		}

		// El header Authorization debería tener el formato "Bearer <token>".
		bearerToken := strings.Split(authHeader, " ")
		if len(bearerToken) != 2 || strings.ToLower(bearerToken[0]) != "bearer" {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "Invalid Authorization header format"})
			return
		}

		// Validar el token JWT.
		tokenString := bearerToken[1]
		claims, err := token.ValidateToken(tokenString)

		// Si la validación falla, retornar la respuesta correspondiente.
		if err != nil {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "Invalid token"})
			return
		}

		// Opcionalmente, puedes almacenar los claims en el contexto de Gin para usarlos más adelante.
		c.Set("claims", claims)

		// Si está bien, continuar con la siguiente función en la cadena.
		c.Next()
	}
}
