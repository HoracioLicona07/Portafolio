package token

import (
	"crypto/rsa"
	"fmt"
	"io/ioutil"
	"time"

	"192.168.1.46/gitlab/e-karpay-code/karpay_10/msgo-generaciontoken/-/tree/Develop/internal/config"

	"github.com/golang-jwt/jwt/v4"
)

const (
	expirationTime = 30 // 30 minutos
)

type Credentials struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

var (
	verifyKey *rsa.PublicKey
	signKey   *rsa.PrivateKey
)

func init() {
	loadKeys()
}

func loadKeys() {
	privateKey, err := ioutil.ReadFile("C:/Users/Esteban Licona/Documents/msgo_GeneracionToken2.0/private_key.pem")
	if err != nil {
		panic(fmt.Errorf("error reading private key: %v", err))
	}

	publicKey, err := ioutil.ReadFile("C:/Users/Esteban Licona/Documents/msgo_GeneracionToken2.0/public_key.pem")
	if err != nil {
		panic(fmt.Errorf("error reading public key: %v", err))
	}

	signKey, err = jwt.ParseRSAPrivateKeyFromPEM(privateKey)
	if err != nil {
		panic(fmt.Errorf("error parsing private key: %v", err))
	}

	verifyKey, err = jwt.ParseRSAPublicKeyFromPEM(publicKey)
	if err != nil {
		panic(fmt.Errorf("error parsing public key: %v", err))
	}
}

func GenerateJWT(username string, cfg *config.Config) (string, error) {
	token := jwt.New(jwt.SigningMethodRS256)

	claims := token.Claims.(jwt.MapClaims)
	claims["authorized"] = true
	claims["user"] = username
	claims["exp"] = time.Now().Add(time.Minute * expirationTime).Unix()

	return token.SignedString(signKey)
}

func ValidateToken(tokenStr string) (jwt.MapClaims, error) {
	token, err := jwt.Parse(tokenStr, func(token *jwt.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwt.SigningMethodRSA); !ok {
			return nil, fmt.Errorf("Unexpected signing method: %v", token.Header["alg"])
		}
		return verifyKey, nil
	})

	if err != nil {
		return nil, err
	}

	claims, ok := token.Claims.(jwt.MapClaims)
	if !ok || !token.Valid {
		return nil, fmt.Errorf("Invalid token")
	}

	return claims, nil
}

func Authenticate(creds *Credentials) (string, error) {
	// Aquí deberías validar las credenciales con tu base de datos o servicio de autenticación.
	if creds.Username != "testuser" || creds.Password != "testpass" {
		return "", fmt.Errorf("Invalid credentials")
	}

	cfg := &config.Config{
		Port: "8081",
	}

	return GenerateJWT(creds.Username, cfg)
}
