package token_test

import (
	"testing"
	"time"

	"192.168.1.46/gitlab/e-karpay-code/karpay_10/msgo-generaciontoken/-/tree/Develop/internal/config"
	"192.168.1.46/gitlab/e-karpay-code/karpay_10/msgo-generaciontoken/-/tree/Develop/pkg/token"

	"github.com/golang-jwt/jwt/v4"
	"github.com/stretchr/testify/assert"
)

const (
	expirationTime = 30 // 30 minutos
)

func TestGenerateJWT(t *testing.T) {
	cfg := &config.Config{
		Port: "8081",
	}

	generatedToken, err := token.GenerateJWT("testuser", cfg)
	assert.NoError(t, err)
	assert.NotEmpty(t, generatedToken)
}

func TestValidateToken(t *testing.T) {
	cfg := &config.Config{
		Port: "8081",
	}

	generatedToken, err := token.GenerateJWT("testuser", cfg)
	assert.NoError(t, err)

	claims, err := token.ValidateToken(generatedToken)
	assert.NoError(t, err)
	assert.NotNil(t, claims)

	assert.True(t, claims["authorized"].(bool))
	assert.Equal(t, "testuser", claims["user"].(string))
}

func TestAuthenticate(t *testing.T) {
	validCreds := &token.Credentials{
		Username: "testuser",
		Password: "testpass",
	}

	invalidCreds := &token.Credentials{
		Username: "invaliduser",
		Password: "invalidpass",
	}

	// Test con credenciales válidas
	generatedToken, err := token.Authenticate(validCreds)
	assert.NoError(t, err)
	assert.NotEmpty(t, generatedToken)

	// Test con credenciales inválidas
	generatedToken, err = token.Authenticate(invalidCreds)
	assert.Error(t, err)
	assert.Empty(t, generatedToken)
}

func TestTokenExpiry(t *testing.T) {
	cfg := &config.Config{
		Port: "8081",
	}

	// Generar un token y validar su tiempo de expiración
	generatedToken, err := token.GenerateJWT("testuser", cfg)
	assert.NoError(t, err)

	// Decodificar el token
	parsedToken, _, err := new(jwt.Parser).ParseUnverified(generatedToken, jwt.MapClaims{})
	assert.NoError(t, err)

	claims, ok := parsedToken.Claims.(jwt.MapClaims)
	assert.True(t, ok)

	// Comparar el tiempo de expiración
	expiry := int64(claims["exp"].(float64))
	assert.LessOrEqual(t, time.Now().Unix(), expiry)
	assert.Greater(t, expiry, time.Now().Unix()-60*expirationTime)
}
